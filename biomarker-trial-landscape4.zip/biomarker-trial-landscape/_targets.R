# =============================================================================
# targets pipeline — the same steps as run_all.R, but cached step by step.
# Only steps whose code or inputs changed are re-run.
#
#   targets::tar_make()        # run (or update) the pipeline
#   targets::tar_visnetwork()  # see the dependency graph
#   targets::tar_read(tabs)    # load a result
#
# The download is a target too; set CFG$refresh <- TRUE (or tar_invalidate(raw))
# to fetch fresh data.
# =============================================================================

library(targets)

tar_source(c("R/00_config.R", "R/01_fetch.R", "R/02_dictionaries.R", "R/03_classify.R",
             "R/04_analyse.R", "R/05_plots.R", "R/06_validation.R", "R/07_extensions.R",
             "R/08_sensitivity.R", "R/09_outcomes.R", "R/10_llm_crosscheck.R",
             "R/11_other_registries.R", "R/12_figures.R"))

list(
  tar_target(dictionaries_file, "R/02_dictionaries.R", format = "file"),
  tar_target(approvals_file, "reference/fda_biomarker_approvals.csv", format = "file"),

  tar_target(raw, fetch_ctg()),
  tar_target(trials0, prepare_trials(raw)),
  tar_target(bm, { dictionaries_file; classify_biomarkers(trials0) }),
  tar_target(tu, classify_tumours(bm$trials)),
  tar_target(mo, classify_modalities(tu$trials)),
  tar_target(ge, classify_geography(mo$trials)),
  tar_target(trials, ge$trials),
  tar_target(approvals, { approvals_file; load_approvals() }),

  tar_target(tabs, analyse_landscape(trials, tu$tumour_long, bm$bm_trial)),
  tar_target(ext,  analyse_extensions(trials, bm$bm_trial, mo$modality_long, ge$region_long, approvals)),
  tar_target(sens, run_sensitivity(trials, bm$bm_trial, tu$tumour_long)),
  tar_target(outc, analyse_outcomes(trials)),

  tar_target(tables, {
    write_tables(tabs, trials); write_extension_tables(ext); write_outcome_tables(outc)
    readr::write_csv(sens$summary, file.path(CFG$out_dir, "sensitivity_summary.csv"))
    TRUE
  }),
  tar_target(figures, {
    clear_figures()
    make_main_figures(tabs, ext, sens); plot_outcomes(outc); plot_sensitivity(sens)
    make_plots(tabs); make_extension_plots(ext, tabs)
    TRUE
  })
)
