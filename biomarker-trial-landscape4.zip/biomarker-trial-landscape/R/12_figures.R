# =============================================================================
# 12_figures.R — the two comprehensive main figures
#
# Figure 1  The rise of biomarker-selected trials
#   a  trial starts per year by sponsor type
#   b  share of all oncology trials, with 95% CI and the range across the
#      sensitivity definitions for the first and last five years
#   c  tumour type x biomarker heatmap, with each tumour's total alongside
#   d  drug types tested in biomarker-selected trials over time
#   e  momentum: annual growth of each major biomarker, with 95% CI
#
# Figure 2  Who invests, where, and what follows approval
#   a  investment map of tumour types (industry share vs growth)
#   b  regional shift of trial sites
#   c  company portfolios (share of each sponsor's trials per biomarker)
#   d  trial activity around a biomarker's first FDA approval
# =============================================================================

CAT_PAL <- c("#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948")

theme_panel <- function() {
  theme_landscape(9.5) +
    theme(plot.title    = element_text(face = "bold", size = 11.5),
          plot.subtitle = element_text(size = 8.8, colour = PAL$ink2),
          plot.tag      = element_text(face = "bold", size = 14),
          legend.text   = element_text(size = 8.5),
          legend.key.size = unit(0.4, "cm"))
}

year_axis <- function(width = 4) {
  scale_x_continuous(breaks = scales::breaks_width(width), labels = function(x) sprintf("%d", as.integer(x)),
                     expand = expansion(add = 0.6))
}

# ---- Figure 1 -------------------------------------------------------------------
figure1_landscape <- function(tabs, ext, sens) {
  yrs <- range(tabs$by_year$start_year)

  # a. Counts by sponsor type
  da <- tabs$by_year |>
    select(start_year, Industry = n_bm_industry, `Non-industry` = n_bm_nonind) |>
    pivot_longer(-start_year, names_to = "sponsor_type", values_to = "n")
  pa <- ggplot(da, aes(start_year, n, fill = sponsor_type)) +
    geom_col(width = 0.82, colour = "white", linewidth = 0.3) +
    scale_fill_manual(values = c(Industry = PAL$industry, `Non-industry` = PAL$non_industry), name = NULL) +
    scale_y_continuous(labels = scales::label_comma(), expand = expansion(c(0, 0.05))) +
    year_axis() +
    labs(title = "Biomarker-selected trials started per year",
         subtitle = "By lead sponsor", x = NULL, y = "Trials") +
    theme_panel()

  # b. Share with CI and sensitivity ranges
  first5 <- c(yrs[1], yrs[1] + 4); last5 <- c(yrs[2] - 4, yrs[2])
  rng <- tibble(
    x  = c(mean(first5), mean(last5)),
    lo = c(min(sens$summary$pct_2005_09), min(sens$summary$pct_2021_25)),
    hi = c(max(sens$summary$pct_2005_09), max(sens$summary$pct_2021_25)),
    xmin = c(first5[1] - 0.4, last5[1] - 0.4), xmax = c(first5[2] + 0.4, last5[2] + 0.4)
  )
  ends <- tabs$by_year |> filter(start_year %in% yrs)
  pb <- ggplot(tabs$by_year, aes(start_year, pct_bm)) +
    geom_rect(data = rng, aes(xmin = xmin, xmax = xmax, ymin = lo, ymax = hi), inherit.aes = FALSE,
              fill = PAL$accent, alpha = 0.18) +
    geom_ribbon(aes(ymin = pct_bm_lo, ymax = pct_bm_hi), fill = PAL$seq[2], alpha = 0.7) +
    geom_line(colour = PAL$industry, linewidth = 0.9) +
    geom_point(colour = PAL$industry, size = 1.6) +
    geom_text(data = ends, aes(label = scales::percent(pct_bm, accuracy = 1)),
              vjust = -1.1, size = 3.2, fontface = "bold", colour = PAL$ink) +
    scale_y_continuous(labels = scales::label_percent(accuracy = 1), limits = c(0, NA),
                       expand = expansion(c(0, 0.12))) +
    year_axis() +
    labs(title = "Share of oncology treatment trials that are biomarker-selected",
         subtitle = "Blue band: 95% CI. Green boxes: range across the 7 sensitivity definitions (first and last 5 years)",
         x = NULL, y = NULL) +
    theme_panel()

  # c. Heatmap + totals
  top_bm <- tabs$by_biomarker |> filter(in_headline) |> slice_max(n_trials, n = 14) |> pull(biomarker)
  top_tu <- tabs$by_tumour |> filter(!tumour %in% c("Other / unspecified")) |>
    slice_max(n_bm, n = 15) |> pull(tumour)
  dc <- tabs$tumour_biomarker |>
    filter(biomarker %in% top_bm, tumour %in% top_tu) |>
    select(tumour, biomarker, n_trials) |>
    complete(tumour = top_tu, biomarker = top_bm, fill = list(n_trials = 0L)) |>
    mutate(tumour = factor(tumour, levels = rev(top_tu)), biomarker = factor(biomarker, levels = top_bm),
           lab_col = n_trials > 150)
  pc <- ggplot(dc, aes(biomarker, tumour, fill = n_trials)) +
    geom_tile(colour = "white", linewidth = 0.7) +
    geom_text(aes(label = ifelse(n_trials > 0, scales::comma(n_trials), ""), colour = lab_col),
              size = 2.6, show.legend = FALSE) +
    scale_colour_manual(values = c(`TRUE` = "white", `FALSE` = PAL$ink)) +
    scale_fill_gradientn(colours = c("#f4f4f2", PAL$seq), trans = "log1p",
                         breaks = c(0, 10, 100, 1000), labels = scales::label_comma(), name = "Trials") +
    labs(title = "Which biomarkers are used in which tumours",
         subtitle = "Trials positively selecting for each biomarker (a trial can count in several cells)",
         x = NULL, y = NULL) +
    theme_panel() +
    theme(axis.text.x = element_text(angle = 35, hjust = 1), panel.grid = element_blank(),
          legend.position = "left")

  dcb <- tabs$by_tumour |> filter(tumour %in% top_tu) |>
    mutate(tumour = factor(tumour, levels = rev(top_tu)))
  pcb <- ggplot(dcb, aes(n_bm, tumour)) +
    geom_col(fill = PAL$industry, width = 0.7) +
    geom_text(aes(label = sprintf("%s  %s", scales::comma(n_bm), scales::percent(pct_bm, accuracy = 1))),
              hjust = -0.08, size = 2.6, colour = PAL$ink2) +
    scale_x_continuous(expand = expansion(c(0, 0.6)), breaks = NULL) +
    labs(title = "Total", subtitle = "Trials, % of tumour's trials", x = NULL, y = NULL) +
    theme_panel() +
    theme(axis.text.y = element_blank(), panel.grid = element_blank())

  # d. Drug types
  mods <- c("Targeted small molecule", "Checkpoint inhibitor", "Antibody-drug conjugate",
            "Cell therapy", "Bispecific / T-cell engager", "Radioligand / radionuclide")
  dd <- ext$modality_year |> filter(modality %in% mods) |>
    mutate(modality = factor(modality, levels = mods))
  dd_end <- dd |> group_by(modality) |> filter(start_year == max(start_year)) |> ungroup()
  pd <- ggplot(dd, aes(start_year, share_of_bm, colour = modality)) +
    geom_line(linewidth = 0.85) +
    ggrepel::geom_text_repel(data = dd_end, aes(label = modality), direction = "y", hjust = 0,
                             nudge_x = 0.6, size = 2.8, segment.colour = PAL$grid,
                             xlim = c(yrs[2] + 0.5, NA), seed = CFG$seed) +
    scale_colour_manual(values = setNames(CAT_PAL[1:6], mods), guide = "none") +
    scale_y_continuous(labels = scales::label_percent(accuracy = 1), limits = c(0, NA)) +
    scale_x_continuous(breaks = scales::breaks_width(4), labels = function(x) sprintf("%d", as.integer(x)),
                       expand = expansion(add = c(0.6, 7.5))) +
    labs(title = "Drug types tested in biomarker-selected trials",
         subtitle = "Share of each year's biomarker-selected trials testing the drug type (experimental arms)",
         x = NULL, y = NULL) +
    theme_panel()

  # e. Momentum of biomarkers
  ref <- tabs$overall_growth |> filter(key == "All oncology trials") |> pull(growth)
  de <- tabs$by_biomarker |> filter(in_headline, !is.na(growth)) |>
    slice_max(n_trials, n = 18) |>
    mutate(biomarker = fct_reorder(biomarker, growth))
  pe <- ggplot(de, aes(growth, biomarker)) +
    geom_vline(xintercept = ref, linetype = "dashed", colour = PAL$ink2, linewidth = 0.4) +
    geom_vline(xintercept = 0, colour = PAL$grid) +
    geom_errorbarh(aes(xmin = growth_lo, xmax = growth_hi), height = 0, colour = PAL$seq[3], linewidth = 0.7) +
    geom_point(aes(size = n_trials, shape = small_n), colour = PAL$industry, stroke = 0.9) +
    scale_shape_manual(values = c(`FALSE` = 16, `TRUE` = 1), guide = "none") +
    scale_size_area(max_size = 6, name = "Trials", labels = scales::label_comma()) +
    scale_x_continuous(labels = scales::label_percent(accuracy = 1)) +
    labs(title = "Momentum by biomarker",
         subtitle = sprintf("Annual growth in trial starts %d–%d, 95%% CI. Dashed: all oncology trials",
                            CFG$growth_years[1], CFG$growth_years[2]),
         x = NULL, y = NULL) +
    theme_panel() + theme(legend.position = "right")

  design <- "
  AABB
  CCCD
  EEFF
  "
  fig <- pa + pb + pc + pcb + pd + pe +
    patchwork::plot_layout(design = design, heights = c(1, 1.55, 1.15)) +
    patchwork::plot_annotation(
      title = "The rise of biomarker-selected oncology trials, 2005–2025",
      subtitle = sprintf("%s interventional oncology treatment trials on ClinicalTrials.gov; %s (%s) select patients by biomarker",
                         scales::comma(sum(tabs$by_year$n_trials)), scales::comma(sum(tabs$by_year$n_bm)),
                         scales::percent(sum(tabs$by_year$n_bm) / sum(tabs$by_year$n_trials), accuracy = 0.1)),
      caption = SOURCE_CAPTION, tag_levels = list(c("a", "b", "c", "", "d", "e")),
      theme = theme(plot.title = element_text(face = "bold", size = 17),
                    plot.subtitle = element_text(size = 11, colour = PAL$ink2),
                    plot.caption = element_text(size = 8, colour = PAL$ink2, hjust = 0))
    )
  save_fig(fig, "fig_main1_landscape", width = 15, height = 16.5)
  invisible(fig)
}

# ---- Figure 2 -------------------------------------------------------------------
figure2_investment <- function(tabs, ext) {
  ref <- tabs$overall_growth |> filter(key == "All oncology trials") |> pull(growth)

  # a. Investment map
  da <- tabs$by_tumour |> filter(!is.na(bm_growth), tumour != "Other / unspecified")
  pa <- ggplot(da, aes(bm_industry_share, bm_growth)) +
    geom_hline(yintercept = ref, linetype = "dashed", colour = PAL$ink2, linewidth = 0.4) +
    annotate("text", x = min(da$bm_industry_share), y = ref, label = "all oncology trials",
             vjust = -0.5, hjust = 0, size = 2.7, colour = PAL$ink2) +
    geom_errorbar(aes(ymin = bm_growth_lo, ymax = bm_growth_hi, colour = category),
                  width = 0, linewidth = 0.35, alpha = 0.45) +
    geom_point(aes(size = n_bm, colour = category, shape = small_n), alpha = 0.85, stroke = 0.9) +
    ggrepel::geom_text_repel(aes(label = tumour), size = 2.7, colour = PAL$ink, max.overlaps = Inf,
                             box.padding = 0.35, min.segment.length = 0.15,
                             segment.colour = PAL$ink2, segment.size = 0.25, seed = CFG$seed) +
    scale_colour_manual(values = c("Solid" = PAL$industry, "Haematological" = PAL$non_industry,
                                   "Pan-tumour / multiple" = PAL$accent), name = NULL) +
    scale_shape_manual(values = c(`FALSE` = 16, `TRUE` = 1), guide = "none") +
    scale_size_area(max_size = 13, name = "Trials", labels = scales::label_comma()) +
    scale_x_continuous(labels = scales::label_percent(accuracy = 1)) +
    scale_y_continuous(labels = scales::label_percent(accuracy = 1)) +
    coord_cartesian(ylim = c(min(-0.1, min(da$bm_growth, na.rm = TRUE)), max(0.45, max(da$bm_growth, na.rm = TRUE)))) +
    labs(title = "Investment map of tumour types",
         subtitle = "Industry-led share vs annual growth of biomarker-selected trials (95% CI); hollow = < 50 trials",
         x = "Industry-led share", y = "Annual growth") +
    theme_panel() + theme(legend.position = "bottom")

  # b. Regional shift
  regs <- c("United States", "China", "Europe", "Japan", "Other Asia-Pacific")
  db <- ext$region_year |> filter(region %in% regs) |>
    mutate(region = factor(region, levels = regs))
  db_end <- db |> group_by(region) |> filter(start_year == max(start_year)) |> ungroup()
  yr_max <- max(db$start_year)
  pb <- ggplot(db, aes(start_year, share_of_bm_trials, colour = region)) +
    geom_line(linewidth = 0.9) +
    geom_point(size = 1.1) +
    ggrepel::geom_text_repel(data = db_end, aes(label = sprintf("%s %s", region, scales::percent(share_of_bm_trials, accuracy = 1))),
                             direction = "y", hjust = 0, nudge_x = 0.6, size = 2.9,
                             xlim = c(yr_max + 0.5, NA), segment.colour = PAL$grid, seed = CFG$seed) +
    scale_colour_manual(values = REGION_COLOURS[regs], guide = "none") +
    scale_y_continuous(labels = scales::label_percent(accuracy = 1), limits = c(0, NA)) +
    scale_x_continuous(breaks = scales::breaks_width(4), labels = function(x) sprintf("%d", as.integer(x)),
                       expand = expansion(add = c(0.6, 7))) +
    labs(title = "Where biomarker-selected trials recruit",
         subtitle = "Share of each year's trials with at least one site in the region",
         x = NULL, y = NULL) +
    theme_panel()

  # c. Company portfolios
  top_sp <- ext$portfolio_summary |> slice_max(n_bm_trials, n = 14, with_ties = FALSE) |> pull(parent)
  top_bm <- tabs$by_biomarker |> filter(in_headline) |> slice_max(n_trials, n = 12) |> pull(biomarker)
  dc <- ext$portfolio_biomarker |>
    filter(parent %in% top_sp, biomarker %in% top_bm) |>
    select(parent, biomarker, n_trials, share_of_portfolio) |>
    complete(parent = top_sp, biomarker = top_bm, fill = list(n_trials = 0L, share_of_portfolio = 0)) |>
    left_join(select(ext$portfolio_summary, parent, n_bm_trials, recent_share), by = "parent") |>
    mutate(parent_lab = sprintf("%s (%d; %s recent)", parent, n_bm_trials,
                                scales::percent(recent_share, accuracy = 1)),
           parent_lab = factor(parent_lab, levels = rev(unique(parent_lab[match(top_sp, parent)]))),
           biomarker  = factor(biomarker, levels = top_bm))
  pc <- ggplot(dc, aes(biomarker, parent_lab, fill = share_of_portfolio)) +
    geom_tile(colour = "white", linewidth = 0.6) +
    geom_text(aes(label = ifelse(n_trials > 0, n_trials, ""),
                  colour = share_of_portfolio > 0.22), size = 2.5, show.legend = FALSE) +
    scale_colour_manual(values = c(`TRUE` = "white", `FALSE` = PAL$ink)) +
    scale_fill_gradientn(colours = c("#f4f4f2", PAL$seq), labels = scales::label_percent(accuracy = 1),
                         name = "Share of\nportfolio") +
    labs(title = "Company portfolios",
         subtitle = "Share of each sponsor's biomarker-selected trials (number = trials); label: total, % started 2021–25",
         x = NULL, y = NULL) +
    theme_panel() +
    theme(axis.text.x = element_text(angle = 35, hjust = 1), panel.grid = element_blank(),
          legend.position = "right")

  # d. Event study
  pd <- ggplot(ext$event_study, aes(rel_year, mean_index)) +
    geom_vline(xintercept = 0, colour = PAL$non_industry, linetype = "dashed") +
    geom_hline(yintercept = 1, colour = PAL$ink2, linewidth = 0.3) +
    geom_ribbon(aes(ymin = mean_index - 1.96 * se, ymax = mean_index + 1.96 * se),
                fill = PAL$seq[2], alpha = 0.65) +
    geom_line(colour = PAL$industry, linewidth = 0.9) +
    geom_point(colour = PAL$industry, size = 1.8) +
    annotate("text", x = 0.15, y = max(ext$event_study$mean_index + 1.96 * ext$event_study$se),
             label = "first FDA approval", hjust = 0, vjust = 1, size = 2.8, colour = PAL$non_industry) +
    scale_x_continuous(breaks = min(ext$event_study$rel_year):max(ext$event_study$rel_year)) +
    labs(title = "Trial activity around a biomarker's first FDA approval",
         subtitle = sprintf("Biomarker's share of trial starts, indexed to its own average; %d biomarkers; 95%% CI",
                            nrow(ext$event_biomarkers)),
         x = "Years relative to first approval", y = "Index (1 = average)") +
    theme_panel()

  fig <- pa + pb + pc + pd +
    patchwork::plot_layout(ncol = 2, heights = c(1.15, 1), widths = c(1.15, 1)) +
    patchwork::plot_annotation(
      title = "Who invests, where, and what follows approval",
      subtitle = "Industry sponsorship and growth as investment proxies; site countries; parent companies; curated FDA approvals",
      caption = paste(SOURCE_CAPTION, "Approvals: reference/fda_biomarker_approvals.csv (hand-curated)."),
      tag_levels = "a",
      theme = theme(plot.title = element_text(face = "bold", size = 17),
                    plot.subtitle = element_text(size = 11, colour = PAL$ink2),
                    plot.caption = element_text(size = 8, colour = PAL$ink2, hjust = 0))
    )
  save_fig(fig, "fig_main2_investment", width = 17, height = 14)
  invisible(fig)
}

make_main_figures <- function(tabs, ext, sens) {
  figure1_landscape(tabs, ext, sens)
  figure2_investment(tabs, ext)
}
