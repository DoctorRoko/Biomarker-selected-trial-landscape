# =============================================================================
# 09_outcomes.R — new questions on the same data
#
#   1. Success: are biomarker-selected trials terminated less often? Why do
#      trials stop? Do they post results? (adjusted logistic regression)
#   2. Size and speed: enrolment and start-to-primary-completion time
#   3. Designs: basket / umbrella / platform trials over time
#   4. Liquid biopsy: selection by a blood test (ctDNA) rather than tissue
#
# Outcome analyses use trials started up to CFG$outcome_max_start_year so that
# recent trials, most of which are still running, don't bias the comparison.
# =============================================================================

parse_ctg_date <- function(x) {
  x <- ifelse(!is.na(x) & nchar(x) == 7, paste0(x, "-15"), x)   # "2019-03" -> mid-month
  suppressWarnings(as.Date(x))
}

classify_stop_reason <- function(why) {
  out <- rep(NA_character_, length(why))
  for (i in seq_len(nrow(STOP_REASONS))) {
    hit <- is.na(out) & !is.na(why) & str_detect(why, regex(STOP_REASONS$pattern[i]))
    out[hit] <- STOP_REASONS$reason[i]
  }
  case_when(!is.na(out) ~ out, is.na(why) | why == "" ~ "Not stated", TRUE ~ "Other")
}

# Tidy odds ratios / ratios from a glm, Wald 95% CI
tidy_effect <- function(fit, term, label, exponentiate = TRUE) {
  b  <- coef(fit)[[term]]
  se <- sqrt(vcov(fit)[term, term])
  f  <- if (exponentiate) exp else identity
  tibble(model = label, estimate = f(b), lo = f(b - 1.96 * se), hi = f(b + 1.96 * se),
         p_value = 2 * pnorm(-abs(b / se)), n = nobs(fit))
}

prepare_outcomes <- function(trials) {
  trials |>
    mutate(
      start_period = cut(start_year, c(2004, 2009, 2014, 2020, 2025),
                         labels = c("2005-09", "2010-14", "2015-20", "2021-25")),
      closed       = status %in% c("COMPLETED", "TERMINATED"),
      terminated   = status == "TERMINATED",
      stop_reason  = if_else(terminated, classify_stop_reason(why_stopped), NA_character_),
      start_d      = parse_ctg_date(start_date),
      pcd_d        = parse_ctg_date(primary_completion_date),
      duration_months = as.numeric(pcd_d - start_d) / 30.44,
      selection    = if_else(biomarker_selected, "Biomarker-selected", "Not selected"),
      category4    = coalesce(tumour_category, "Other / unspecified")
    )
}

analyse_outcomes <- function(trials) {
  d <- prepare_outcomes(trials)
  window <- filter(d, start_year <= CFG$outcome_max_start_year) |> droplevels()
  closed <- filter(window, closed)
  covars <- "phase + sponsor_type + start_period + category4"

  # ---- 1. Termination ----------------------------------------------------------
  f_term <- as.formula(paste("terminated ~ biomarker_selected +", covars))
  m_all  <- glm(f_term, family = binomial(), data = closed)
  effects <- tidy_effect(m_all, "biomarker_selectedTRUE", "Terminated (any reason), adjusted")

  m_raw  <- glm(terminated ~ biomarker_selected, family = binomial(), data = closed)
  effects <- bind_rows(effects, tidy_effect(m_raw, "biomarker_selectedTRUE", "Terminated (any reason), unadjusted"))

  # Terminated for a specific reason vs completed
  for (r in c("Efficacy / futility", "Accrual / enrolment", "Safety / toxicity", "Business / strategic")) {
    dd <- closed |> filter(!terminated | stop_reason == r) |>
      mutate(y = terminated)
    fit <- glm(as.formula(paste("y ~ biomarker_selected +", covars)), family = binomial(), data = dd)
    effects <- bind_rows(effects, tidy_effect(fit, "biomarker_selectedTRUE",
                                              paste0("Terminated for ", tolower(r), ", adjusted")))
  }
  # By phase
  for (ph in c("Phase 1", "Phase 2", "Phase 3")) {
    dd  <- filter(closed, phase == ph)
    fit <- glm(as.formula("terminated ~ biomarker_selected + sponsor_type + start_period + category4"),
               family = binomial(), data = dd)
    effects <- bind_rows(effects, tidy_effect(fit, "biomarker_selectedTRUE",
                                              paste0("Terminated, ", ph, " only, adjusted")))
  }

  termination_rates <- closed |>
    group_by(selection, phase) |>
    summarise(n_closed = n(), n_terminated = sum(terminated),
              pct_terminated = n_terminated / n_closed,
              lo = wilson_lo(n_terminated, n_closed), hi = wilson_hi(n_terminated, n_closed),
              .groups = "drop")

  stop_reasons <- closed |>
    filter(terminated) |>
    count(selection, stop_reason) |>
    group_by(selection) |>
    mutate(share = n / sum(n)) |>
    ungroup()

  # ---- Results posting (completed trials) ---------------------------------------
  completed <- filter(window, status == "COMPLETED")
  results_posting <- completed |>
    group_by(selection, sponsor_type) |>
    summarise(n_completed = n(), n_results = sum(has_results),
              pct_results = n_results / n_completed,
              lo = wilson_lo(n_results, n_completed), hi = wilson_hi(n_results, n_completed),
              .groups = "drop")
  m_res <- glm(as.formula(paste("has_results ~ biomarker_selected +", covars)),
               family = binomial(), data = completed)
  effects <- bind_rows(effects, tidy_effect(m_res, "biomarker_selectedTRUE", "Results posted (completed trials), adjusted"))

  # ---- 2. Size and speed --------------------------------------------------------
  size <- completed |> filter(enrollment_type == "ACTUAL", !is.na(enrollment), enrollment > 0)
  enrolment_summary <- size |>
    group_by(selection, phase) |>
    summarise(n = n(), median = median(enrollment),
              q1 = quantile(enrollment, 0.25), q3 = quantile(enrollment, 0.75), .groups = "drop")
  m_size <- lm(as.formula(paste("log(enrollment) ~ biomarker_selected +", covars)), data = size)
  size_effect <- tidy_effect(m_size, "biomarker_selectedTRUE", "Actual enrolment (ratio), adjusted")

  speed <- completed |> filter(!is.na(duration_months), duration_months > 0, duration_months < 240)
  duration_summary <- speed |>
    group_by(selection, phase) |>
    summarise(n = n(), median = median(duration_months),
              q1 = quantile(duration_months, 0.25), q3 = quantile(duration_months, 0.75),
              .groups = "drop")
  m_speed <- lm(as.formula(paste("log(duration_months) ~ biomarker_selected +", covars)), data = speed)
  speed_effect <- tidy_effect(m_speed, "biomarker_selectedTRUE",
                              "Start to primary completion (ratio), adjusted")

  ratio_effects <- bind_rows(size_effect, speed_effect)

  # ---- 3. Designs ----------------------------------------------------------------
  design_txt <- paste(coalesce(d$brief_title, ""), coalesce(d$official_title, ""),
                      coalesce(d$keywords, ""), sep = " | ")
  design_long <- purrr::map_dfr(seq_len(nrow(DESIGN_PATTERNS)), function(i) {
    hit <- str_detect(design_txt, regex(DESIGN_PATTERNS$pattern[i]))
    tibble(nct_id = d$nct_id[hit], design = DESIGN_PATTERNS$design[i])
  })
  design_year <- design_long |>
    inner_join(select(d, nct_id, start_year, biomarker_selected), by = "nct_id") |>
    count(design, start_year, name = "n_trials") |>
    complete(design, start_year = min(d$start_year):max(d$start_year), fill = list(n_trials = 0L))
  design_summary <- design_long |>
    inner_join(select(d, nct_id, start_year, biomarker_selected, sponsor_type), by = "nct_id") |>
    group_by(design) |>
    summarise(n_trials = n(), pct_bm = mean(biomarker_selected),
              industry_share = mean(sponsor_type == "Industry"),
              n_recent = sum(start_year %in% CFG$recent_years[1]:CFG$recent_years[2]),
              .groups = "drop") |>
    left_join(growth_by_key(design_long |>
                              inner_join(select(d, nct_id, start_year), by = "nct_id") |>
                              rename(key = design), "growth"),
              by = c("design" = "key"))

  # ---- 4. Liquid biopsy ------------------------------------------------------------
  sel <- filter(d, biomarker_selected) |>
    mutate(liquid = str_detect(split_inclusion(eligibility), regex(LIQUID_BIOPSY_PATTERN)))
  liquid_year <- sel |>
    group_by(start_year) |>
    summarise(n_bm = n(), n_liquid = sum(liquid), pct = n_liquid / n_bm,
              lo = wilson_lo(n_liquid, n_bm), hi = wilson_hi(n_liquid, n_bm), .groups = "drop")

  list(
    effects = effects, ratio_effects = ratio_effects,
    termination_rates = termination_rates, stop_reasons = stop_reasons,
    results_posting = results_posting,
    enrolment_summary = enrolment_summary, duration_summary = duration_summary,
    design_year = design_year, design_summary = design_summary,
    liquid_year = liquid_year,
    liquid_trials = select(filter(sel, liquid), nct_id),
    design_trials = design_long
  )
}

plot_outcomes <- function(out) {
  plots <- list()

  # 21. Forest plot of odds ratios
  d21 <- out$effects |> mutate(model = fct_rev(fct_inorder(model)))
  plots$fig21_termination_forest <- ggplot(d21, aes(estimate, model)) +
    geom_vline(xintercept = 1, colour = PAL$ink2, linewidth = 0.3) +
    geom_errorbarh(aes(xmin = lo, xmax = hi), height = 0, colour = PAL$industry, linewidth = 0.6) +
    geom_point(colour = PAL$industry, size = 2.6) +
    scale_x_log10() +
    labs(title = "Biomarker selection and trial outcomes",
         subtitle = sprintf("Odds ratios, biomarker-selected vs not (< 1 = less likely). Closed trials started %s–%d.\nAdjusted for phase, sponsor type, start period and tumour category; lines = 95%% CI",
                            substr(CFG$start_from, 1, 4), CFG$outcome_max_start_year),
         x = "Odds ratio (log scale)", y = NULL, caption = SOURCE_CAPTION) +
    theme_landscape()

  # 22. Stop reasons
  d22 <- out$stop_reasons |>
    mutate(stop_reason = fct_reorder(stop_reason, share, .fun = max))
  plots$fig22_stop_reasons <- ggplot(d22, aes(share, stop_reason, fill = selection)) +
    geom_col(position = position_dodge(width = 0.75), width = 0.7) +
    scale_fill_manual(values = c("Biomarker-selected" = PAL$industry, "Not selected" = PAL$non_industry),
                      name = NULL) +
    scale_x_continuous(labels = scales::label_percent(accuracy = 1)) +
    labs(title = "Why terminated trials stopped",
         subtitle = "Share of terminated trials by stated reason (text-mined from 'why stopped')",
         x = "Share of terminated trials", y = NULL, caption = SOURCE_CAPTION) +
    theme_landscape()

  # 23. Enrolment
  d23 <- out$enrolment_summary |> filter(phase %in% c("Phase 1", "Phase 2", "Phase 3"))
  plots$fig23_enrolment <- ggplot(d23, aes(median, phase, colour = selection)) +
    geom_errorbarh(aes(xmin = q1, xmax = q3), height = 0, linewidth = 0.8,
                   position = position_dodge(width = 0.5)) +
    geom_point(size = 3, position = position_dodge(width = 0.5)) +
    scale_colour_manual(values = c("Biomarker-selected" = PAL$industry, "Not selected" = PAL$non_industry),
                        name = NULL) +
    scale_x_log10(labels = scales::label_comma()) +
    labs(title = "Actual enrolment of completed trials",
         subtitle = "Median (point) and interquartile range (line); log scale",
         x = "Patients enrolled", y = NULL, caption = SOURCE_CAPTION) +
    theme_landscape()

  # 24. Duration
  d24 <- out$duration_summary |> filter(phase %in% c("Phase 1", "Phase 2", "Phase 3"))
  plots$fig24_duration <- ggplot(d24, aes(median, phase, colour = selection)) +
    geom_errorbarh(aes(xmin = q1, xmax = q3), height = 0, linewidth = 0.8,
                   position = position_dodge(width = 0.5)) +
    geom_point(size = 3, position = position_dodge(width = 0.5)) +
    scale_colour_manual(values = c("Biomarker-selected" = PAL$industry, "Not selected" = PAL$non_industry),
                        name = NULL) +
    labs(title = "Time from start to primary completion (completed trials)",
         subtitle = "Median (point) and interquartile range (line)",
         x = "Months", y = NULL, caption = SOURCE_CAPTION) +
    theme_landscape()

  # 25. Designs
  plots$fig25_designs <- ggplot(out$design_year, aes(start_year, n_trials, colour = design)) +
    geom_line(linewidth = 0.8) +
    geom_point(size = 1.4) +
    scale_colour_manual(values = c(Basket = PAL$industry, Umbrella = PAL$non_industry,
                                   Platform = PAL$accent), name = NULL) +
    scale_x_continuous(breaks = scales::breaks_width(2)) +
    labs(title = "Basket, umbrella and platform trials",
         subtitle = "Oncology treatment trials whose title or keywords describe the design",
         x = "Start year", y = "Trials", caption = SOURCE_CAPTION) +
    theme_landscape()

  # 26. Liquid biopsy
  plots$fig26_liquid_biopsy <- ggplot(out$liquid_year, aes(start_year, pct)) +
    geom_ribbon(aes(ymin = lo, ymax = hi), fill = PAL$seq[2], alpha = 0.6) +
    geom_line(colour = PAL$industry, linewidth = 0.8) +
    geom_point(colour = PAL$industry, size = 1.8) +
    scale_y_continuous(labels = scales::label_percent(accuracy = 1), limits = c(0, NA)) +
    scale_x_continuous(breaks = scales::breaks_width(2)) +
    labs(title = "Selection by blood test (liquid biopsy / ctDNA)",
         subtitle = "Share of biomarker-selected trials whose inclusion criteria mention ctDNA, cfDNA or plasma testing; band = 95% CI",
         x = "Start year", y = "Share of biomarker-selected trials", caption = SOURCE_CAPTION) +
    theme_landscape()

  sizes <- list(fig21_termination_forest = c(10, 6), fig22_stop_reasons = c(9, 5),
                fig23_enrolment = c(9, 4.5), fig24_duration = c(9, 4.5))
  for (nm in names(plots)) {
    s <- sizes[[nm]] %||% c(9, 5.5)
    save_fig(plots[[nm]], nm, width = s[1], height = s[2])
  }
  invisible(plots)
}

write_outcome_tables <- function(out) {
  for (nm in names(out)) {
    readr::write_csv(out[[nm]], file.path(CFG$out_dir, paste0("outcome_", nm, ".csv")))
  }
}
