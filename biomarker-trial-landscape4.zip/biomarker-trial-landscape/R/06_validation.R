# =============================================================================
# 06_validation.R — check the text-mining classifier against manual review
#
# Step 1 (automatic, in run_all.R): draw a random sample of classified trials
#   and write output/validation_sample.csv.
# Step 2 (you): open the CSV, read 'inclusion_excerpt', and fill the column
#   'manual_selected' with TRUE or FALSE. Save as output/validation_labelled.csv.
# Step 3: source("R/00_config.R"); source("R/06_validation.R"); score_validation()
# =============================================================================

draw_validation_sample <- function(trials, n_each = 50) {
  set.seed(CFG$seed)
  pos <- trials |> filter(biomarker_selected)  |> slice_sample(n = min(n_each, sum(trials$biomarker_selected)))
  neg <- trials |> filter(!biomarker_selected) |> slice_sample(n = min(n_each, sum(!trials$biomarker_selected)))
  sample <- bind_rows(pos, neg) |>
    slice_sample(prop = 1) |>                       # shuffle so labels are blind
    transmute(
      nct_id, url = paste0("https://clinicaltrials.gov/study/", nct_id),
      brief_title, conditions,
      inclusion_excerpt = str_trunc(str_squish(split_inclusion(eligibility)), 1500),
      classifier_selected = biomarker_selected,
      classifier_biomarkers = biomarkers,
      classifier_evidence = evidence,
      manual_selected = NA
    )
  path <- file.path(CFG$out_dir, "validation_sample.csv")
  readr::write_csv(sample, path, na = "")
  message("  validation sample written to ", path,
          " — label 'manual_selected' and save as validation_labelled.csv")
  invisible(sample)
}

score_validation <- function(path = file.path(CFG$out_dir, "validation_labelled.csv")) {
  v <- readr::read_csv(path, show_col_types = FALSE) |>
    mutate(manual_selected = as.logical(manual_selected)) |>
    filter(!is.na(manual_selected))
  tp <- sum(v$classifier_selected &  v$manual_selected)
  fp <- sum(v$classifier_selected & !v$manual_selected)
  fn <- sum(!v$classifier_selected &  v$manual_selected)
  tn <- sum(!v$classifier_selected & !v$manual_selected)
  precision <- tp / (tp + fp)   # of trials flagged, how many truly selected
  npv       <- tn / (tn + fn)   # of trials not flagged, how many truly not

  # The sample is stratified 50/50, so re-weight to the full dataset to get recall
  all <- readr::read_csv(file.path(CFG$out_dir, "trials_classified.csv"),
                         col_select = "biomarker_selected", show_col_types = FALSE)
  P <- sum(all$biomarker_selected); N <- sum(!all$biomarker_selected)
  est_true_pos  <- P * precision
  est_false_neg <- N * (1 - npv)

  out <- tibble(
    labelled = nrow(v), tp = tp, fp = fp, fn = fn, tn = tn,
    precision = precision, npv = npv,
    recall_population = est_true_pos / (est_true_pos + est_false_neg),
    corrected_n_selected = round(est_true_pos + est_false_neg)
  )
  print(out)
  readr::write_csv(out, file.path(CFG$out_dir, "validation_scores.csv"))
  invisible(out)
}
