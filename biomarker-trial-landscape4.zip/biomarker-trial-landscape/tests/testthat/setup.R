# Load the project's functions from the project root (two levels up)
root <- normalizePath(file.path("..", ".."))
owd  <- setwd(root)
for (f in c("00_config.R", "01_fetch.R", "02_dictionaries.R", "03_classify.R",
            "04_analyse.R", "07_extensions.R", "09_outcomes.R")) {
  source(file.path("R", f))
}
setwd(owd)

# Classify one inclusion-criteria line and return the per-biomarker status
bm_status <- function(line, title = "A study") {
  t <- tibble(nct_id = "NCT00000001", brief_title = title, official_title = NA_character_,
              eligibility = paste0("Inclusion Criteria:\n\n* ", line, "\n\nExclusion Criteria:\n\n* None"))
  b <- suppressMessages(classify_biomarkers(t))$bm_trial
  setNames(b$status, b$biomarker)
}

# Classify one intervention name
drug_type <- function(name) {
  t <- tibble(nct_id = "NCT00000001", interventions = paste0("DRUG: ", name),
              interventions_experimental = NA_character_)
  classify_modalities(t)$interventions$modality[1]
}
