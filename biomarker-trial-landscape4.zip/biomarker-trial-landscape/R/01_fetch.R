# =============================================================================
# 01_fetch.R — download oncology interventional trials from ClinicalTrials.gov
# API docs: https://clinicaltrials.gov/data-api/api
# =============================================================================

CTG_URL <- "https://clinicaltrials.gov/api/v2/studies"

# Condition search. ClinicalTrials.gov expands these terms with MeSH synonyms.
ONC_QUERY <- paste(
  "cancer OR neoplasm OR tumor OR tumour OR carcinoma OR malignancy OR",
  "lymphoma OR leukemia OR leukaemia OR myeloma OR sarcoma OR melanoma OR",
  "glioma OR glioblastoma OR myelodysplastic"
)

# Only the fields we need (keeps the download small).
CTG_FIELDS <- c(
  "NCTId", "BriefTitle", "OfficialTitle", "OverallStatus", "StartDate",
  "LeadSponsorName", "LeadSponsorClass", "Condition", "Keyword",
  "StudyType", "Phase", "DesignPrimaryPurpose", "EnrollmentCount",
  "EligibilityCriteria", "InterventionType", "InterventionName",
  "LocationCountry",                      # geography extension
  # enhanced version: outcomes, arms and MeSH terms
  "WhyStopped", "PrimaryCompletionDate", "CompletionDate", "HasResults",
  "EnrollmentType", "ArmsInterventionsModule", "ConditionBrowseModule"
)

# Bump this when parse_studies() gains columns; older caches are then re-downloaded.
CACHE_SENTINEL_COLUMN <- "mesh_terms"

ctg_request <- function(page_token = NULL, fields = CTG_FIELDS) {
  request(CTG_URL) |>
    req_url_query(
      `query.cond`      = ONC_QUERY,
      `filter.advanced` = sprintf(
        "AREA[StudyType]INTERVENTIONAL AND AREA[StartDate]RANGE[%s, %s]",
        CFG$start_from, CFG$start_to
      ),
      fields     = if (is.null(fields)) NULL else paste(fields, collapse = ","),
      pageSize   = CFG$page_size,
      countTotal = "true",
      pageToken  = page_token
    ) |>
    req_user_agent("biomarker-trial-landscape (R, httr2)") |>
    req_retry(max_tries = 6, backoff = function(i) min(60, 2^i)) |>
    req_throttle(rate = 2) |>          # at most 2 requests per second
    req_timeout(180)
}

# ---- JSON -> tibble ----------------------------------------------------------
pick_chr <- function(x, ..., sep = "; ") {
  v <- purrr::pluck(x, ...)
  if (is.null(v) || length(v) == 0) return(NA_character_)
  paste(unlist(v), collapse = sep)
}

parse_studies <- function(studies) {
  ps <- purrr::map(studies, "protocolSection")
  ds <- purrr::map(studies, ~ .x$derivedSection %||% list())
  tibble(
    nct_id         = map_chr(ps, ~ pick_chr(.x, "identificationModule", "nctId")),
    brief_title    = map_chr(ps, ~ pick_chr(.x, "identificationModule", "briefTitle")),
    official_title = map_chr(ps, ~ pick_chr(.x, "identificationModule", "officialTitle")),
    status         = map_chr(ps, ~ pick_chr(.x, "statusModule", "overallStatus")),
    start_date     = map_chr(ps, ~ pick_chr(.x, "statusModule", "startDateStruct", "date")),
    sponsor        = map_chr(ps, ~ pick_chr(.x, "sponsorCollaboratorsModule", "leadSponsor", "name")),
    sponsor_class  = map_chr(ps, ~ pick_chr(.x, "sponsorCollaboratorsModule", "leadSponsor", "class")),
    conditions     = map_chr(ps, ~ pick_chr(.x, "conditionsModule", "conditions")),
    keywords       = map_chr(ps, ~ pick_chr(.x, "conditionsModule", "keywords")),
    study_type     = map_chr(ps, ~ pick_chr(.x, "designModule", "studyType")),
    phases         = map_chr(ps, ~ pick_chr(.x, "designModule", "phases", sep = "|")),
    purpose        = map_chr(ps, ~ pick_chr(.x, "designModule", "designInfo", "primaryPurpose")),
    enrollment     = map_dbl(ps, ~ as.numeric(purrr::pluck(.x, "designModule", "enrollmentInfo",
                                                           "count", .default = NA))),
    eligibility    = map_chr(ps, ~ pick_chr(.x, "eligibilityModule", "eligibilityCriteria")),
    interventions  = map_chr(ps, function(p) {
      iv <- purrr::pluck(p, "armsInterventionsModule", "interventions")
      if (is.null(iv) || length(iv) == 0) return(NA_character_)
      paste(map_chr(iv, ~ paste0(.x$type %||% "?", ": ", .x$name %||% "?")), collapse = "; ")
    }),
    # Unique countries of all trial sites, e.g. "China; United States"
    countries      = map_chr(ps, function(p) {
      locs <- purrr::pluck(p, "contactsLocationsModule", "locations")
      cty  <- sort(unique(unlist(purrr::map(locs %||% list(), "country"))))
      if (length(cty) == 0) NA_character_ else paste(cty, collapse = "; ")
    }),
    # ---- enhanced version ----
    why_stopped    = map_chr(ps, ~ pick_chr(.x, "statusModule", "whyStopped")),
    primary_completion_date = map_chr(ps, ~ pick_chr(.x, "statusModule",
                                                     "primaryCompletionDateStruct", "date")),
    completion_date = map_chr(ps, ~ pick_chr(.x, "statusModule", "completionDateStruct", "date")),
    has_results    = map_lgl(studies, ~ isTRUE(.x$hasResults)),
    enrollment_type = map_chr(ps, ~ pick_chr(.x, "designModule", "enrollmentInfo", "type")),
    # Interventions given in EXPERIMENTAL arms only ("Drug: X; Biological: Y")
    interventions_experimental = map_chr(ps, function(p) {
      arms <- purrr::pluck(p, "armsInterventionsModule", "armGroups")
      if (is.null(arms) || length(arms) == 0) return(NA_character_)
      exp  <- purrr::keep(arms, ~ identical(.x$type, "EXPERIMENTAL"))
      nm   <- unique(unlist(purrr::map(exp, "interventionNames")))
      if (length(nm) == 0) NA_character_ else paste(nm, collapse = "; ")
    }),
    arm_types      = map_chr(ps, function(p) {
      arms <- purrr::pluck(p, "armsInterventionsModule", "armGroups")
      ty   <- unique(unlist(purrr::map(arms %||% list(), "type")))
      if (length(ty) == 0) NA_character_ else paste(sort(ty), collapse = "|")
    }),
    # MeSH condition terms assigned by ClinicalTrials.gov, and their MeSH ancestors
    mesh_terms     = map_chr(ds, function(d) {
      tm <- unique(unlist(purrr::map(purrr::pluck(d, "conditionBrowseModule", "meshes") %||% list(), "term")))
      if (length(tm) == 0) NA_character_ else paste(tm, collapse = "; ")
    }),
    mesh_ancestors = map_chr(ds, function(d) {
      tm <- unique(unlist(purrr::map(purrr::pluck(d, "conditionBrowseModule", "ancestors") %||% list(), "term")))
      if (length(tm) == 0) NA_character_ else paste(tm, collapse = "; ")
    })
  )
}

# ---- Paginated download with caching ----------------------------------------
fetch_ctg <- function() {
  cache <- file.path(CFG$data_dir,
                     if (CFG$test_mode) "ctg_oncology_TEST.rds" else "ctg_oncology_raw.rds")
  if (file.exists(cache) && !CFG$refresh) {
    cached <- readRDS(cache)
    if (CACHE_SENTINEL_COLUMN %in% names(cached)) {
      message("Using cached download: ", cache, " (set CFG$refresh <- TRUE to re-download)")
      return(cached)
    }
    message("Cached download predates the current field list; re-downloading.")
  }

  fields <- CTG_FIELDS
  pages  <- list()
  token  <- NULL
  total  <- NA
  i      <- 0
  repeat {
    resp <- tryCatch(
      req_perform(ctg_request(token, fields)),
      httr2_http_400 = function(e) NULL
    )
    if (is.null(resp)) {
      if (!is.null(fields) && i == 0) {
        message("Server rejected the field list; retrying with full records.")
        fields <- NULL
        next
      }
      stop("ClinicalTrials.gov returned HTTP 400 for this query.")
    }
    i    <- i + 1
    body <- resp_body_json(resp, simplifyVector = FALSE)
    if (i == 1) {
      total <- body$totalCount %||% NA
      message(sprintf("Matching studies on ClinicalTrials.gov: %s", format(total, big.mark = ",")))
    }
    pages[[i]] <- parse_studies(body$studies)
    message(sprintf("  page %d: %s trials downloaded", i,
                    format(sum(map_int(pages, nrow)), big.mark = ",")))
    token <- body$nextPageToken
    if (is.null(token) || (CFG$test_mode && i >= 3)) break
  }

  trials <- bind_rows(pages) |> distinct(nct_id, .keep_all = TRUE)
  attr(trials, "downloaded_at") <- Sys.time()
  attr(trials, "api_total")     <- total
  saveRDS(trials, cache)

  writeLines(c(
    paste("Downloaded:", format(Sys.time(), "%Y-%m-%d %H:%M %Z")),
    paste("Endpoint:", CTG_URL),
    paste("query.cond:", ONC_QUERY),
    sprintf("filter.advanced: AREA[StudyType]INTERVENTIONAL AND AREA[StartDate]RANGE[%s, %s]",
            CFG$start_from, CFG$start_to),
    paste("API totalCount:", total),
    paste("Trials saved:", nrow(trials)),
    paste("Test mode:", CFG$test_mode)
  ), file.path(CFG$out_dir, "run_info.txt"))

  trials
}

# ---- Tidy the raw table -----------------------------------------------------
prepare_trials <- function(raw) {
  out <- raw |>
    mutate(
      start_year   = suppressWarnings(as.integer(substr(start_date, 1, 4))),
      sponsor_type = if_else(sponsor_class == "INDUSTRY", "Industry", "Non-industry",
                             missing = "Non-industry"),
      phase = case_when(
        str_detect(phases, "PHASE4") ~ "Phase 4",
        str_detect(phases, "PHASE3") ~ "Phase 3",
        str_detect(phases, "PHASE2") ~ "Phase 2",
        str_detect(phases, "PHASE1") ~ "Phase 1",
        TRUE                         ~ "Not applicable / unknown"
      ),
      phase = factor(phase, levels = c("Phase 1", "Phase 2", "Phase 3", "Phase 4",
                                       "Not applicable / unknown"))
    ) |>
    filter(!is.na(start_year),
           start_year >= as.integer(substr(CFG$start_from, 1, 4)),
           start_year <= as.integer(substr(CFG$start_to, 1, 4)))

  if (CFG$treatment_only) {
    n0  <- nrow(out)
    out <- filter(out, is.na(purpose) | purpose == "TREATMENT")
    message(sprintf("Kept %s of %s trials with primary purpose = TREATMENT (or missing).",
                    format(nrow(out), big.mark = ","), format(n0, big.mark = ",")))
  }
  out
}
