# =============================================================================
# 04_analyse.R — summary tables: by year, tumour type, biomarker, sponsor
#
# "Investment" is approximated with registry signals:
#   * industry share   — % of biomarker-selected trials with an industry lead sponsor
#   * activity         — number of industry-sponsored biomarker trials, recent years
#   * momentum         — annual growth in biomarker-selected trial starts
#                        (quasi-Poisson log-linear trend over CFG$growth_years)
#   * late-stage spend — Phase 3 count and planned enrolment
# =============================================================================

# Wilson score interval for a proportion k/n (better than +-1.96*SE for small n)
wilson_lo <- function(k, n, z = 1.96) {
  p <- k / n; d <- 1 + z^2 / n
  (p + z^2 / (2 * n) - z * sqrt(p * (1 - p) / n + z^2 / (4 * n^2))) / d
}
wilson_hi <- function(k, n, z = 1.96) {
  p <- k / n; d <- 1 + z^2 / n
  (p + z^2 / (2 * n) + z * sqrt(p * (1 - p) / n + z^2 / (4 * n^2))) / d
}

# Areas with fewer trials than this are flagged as "small" in tables and figures
SMALL_N <- 50

fit_growth <- function(year, n) {
  if (sum(n) < CFG$min_trials_growth) return(c(growth = NA_real_, lo = NA_real_, hi = NA_real_))
  fit <- glm(n ~ year, family = quasipoisson())
  b   <- unname(coef(fit)[2])
  se  <- sqrt(vcov(fit)[2, 2])
  c(growth = exp(b) - 1, lo = exp(b - 1.96 * se) - 1, hi = exp(b + 1.96 * se) - 1)
}

# df needs columns: key, start_year. One growth estimate per key.
growth_by_key <- function(df, prefix = "growth") {
  yrs <- CFG$growth_years[1]:CFG$growth_years[2]
  out <- df |>
    filter(start_year %in% yrs) |>
    count(key, start_year, name = "n") |>
    complete(key, start_year = yrs, fill = list(n = 0L)) |>
    group_by(key) |>
    summarise(g = list(fit_growth(start_year, n)), .groups = "drop") |>
    mutate(growth    = map_dbl(g, ~ .x[["growth"]]),
           growth_lo = map_dbl(g, ~ .x[["lo"]]),
           growth_hi = map_dbl(g, ~ .x[["hi"]])) |>
    select(-g)
  names(out)[-1] <- sub("^growth", prefix, names(out)[-1])
  out
}

clean_sponsor <- function(x) {
  x |>
    str_remove(regex(",?\\s+(inc|ltd|llc|gmbh|ag|s\\.?a|co|corp|corporation|limited|plc|pharmaceuticals?|pharma)\\.?$",
                     ignore_case = TRUE)) |>
    str_remove(regex(",?\\s+(inc|ltd|llc|co)\\.?$", ignore_case = TRUE)) |>
    str_squish()
}

analyse_landscape <- function(trials, tumour_long, bm_trial) {
  recent <- CFG$recent_years[1]:CFG$recent_years[2]

  # ---- 1. Overall trend by year ---------------------------------------------
  by_year <- trials |>
    group_by(start_year) |>
    summarise(
      n_trials        = n(),
      n_bm            = sum(biomarker_selected),
      n_bm_industry   = sum(biomarker_selected & sponsor_type == "Industry"),
      n_bm_nonind     = n_bm - n_bm_industry,
      n_negative_only = sum(negative_selection_only),
      pct_bm          = n_bm / n_trials,
      .groups = "drop"
    ) |>
    mutate(pct_bm_lo = wilson_lo(n_bm, n_trials), pct_bm_hi = wilson_hi(n_bm, n_trials))

  # ---- 2. Tumour type -------------------------------------------------------
  tl <- tumour_long |>
    left_join(select(trials, nct_id, start_year, biomarker_selected, sponsor_type,
                     phase, enrollment), by = "nct_id")

  by_tumour <- tl |>
    group_by(tumour, category) |>
    summarise(
      n_trials          = n(),
      n_bm              = sum(biomarker_selected),
      pct_bm            = n_bm / n_trials,
      bm_industry_share = mean(sponsor_type[biomarker_selected] == "Industry"),
      n_bm_industry_recent = sum(biomarker_selected & sponsor_type == "Industry" &
                                   start_year %in% recent),
      n_bm_phase3       = sum(biomarker_selected & phase == "Phase 3"),
      bm_planned_enrolment = sum(enrollment[biomarker_selected], na.rm = TRUE),
      .groups = "drop"
    ) |>
    left_join(growth_by_key(filter(tl, biomarker_selected) |> rename(key = tumour), "bm_growth"),
              by = c("tumour" = "key")) |>
    left_join(growth_by_key(rename(tl, key = tumour), "all_growth"),
              by = c("tumour" = "key")) |>
    mutate(excess_growth = bm_growth - all_growth,
           pct_bm_lo = wilson_lo(n_bm, n_trials), pct_bm_hi = wilson_hi(n_bm, n_trials),
           small_n   = n_bm < SMALL_N) |>
    arrange(desc(n_bm))

  by_tumour_year <- tl |>
    group_by(tumour, category, start_year) |>
    summarise(n_trials = n(), n_bm = sum(biomarker_selected),
              pct_bm = n_bm / n_trials, .groups = "drop") |>
    mutate(pct_bm_lo = wilson_lo(n_bm, n_trials), pct_bm_hi = wilson_hi(n_bm, n_trials))

  # ---- 3. Biomarker ---------------------------------------------------------
  bm_pos <- bm_trial |>
    filter(status == "positive") |>
    left_join(select(trials, nct_id, start_year, sponsor_type, phase, enrollment),
              by = "nct_id") |>
    filter(!is.na(start_year))

  by_biomarker <- bm_pos |>
    group_by(biomarker, group) |>
    summarise(
      n_trials          = n(),
      pct_of_all_onc    = n_trials / nrow(trials),
      industry_share    = mean(sponsor_type == "Industry"),
      n_industry_recent = sum(sponsor_type == "Industry" & start_year %in% recent),
      n_phase3          = sum(phase == "Phase 3"),
      first_year        = min(start_year),
      in_headline       = !first(group) %in% CFG$primary_exclude_groups,
      .groups = "drop"
    ) |>
    left_join(growth_by_key(rename(bm_pos, key = biomarker), "growth"),
              by = c("biomarker" = "key")) |>
    mutate(small_n = n_trials < SMALL_N) |>
    arrange(desc(n_trials))

  by_biomarker_year <- bm_pos |>
    count(biomarker, group, start_year, name = "n_trials")

  # Negative selection (e.g. "EGFR wild-type", "MSS", "HER2-negative")
  by_biomarker_negative <- bm_trial |>
    filter(nct_id %in% trials$nct_id) |>
    count(biomarker, group, status) |>
    pivot_wider(names_from = status, values_from = n, values_fill = 0)

  # ---- 4. Tumour x biomarker ------------------------------------------------
  tumour_biomarker <- bm_pos |>
    filter(!group %in% CFG$primary_exclude_groups) |>
    select(nct_id, biomarker, sponsor_type) |>
    inner_join(tumour_long, by = "nct_id", relationship = "many-to-many") |>
    group_by(tumour, category, biomarker) |>
    summarise(n_trials = n(), industry_share = mean(sponsor_type == "Industry"),
              .groups = "drop")

  # ---- 5. Sponsors ----------------------------------------------------------
  sponsors <- trials |>
    filter(biomarker_selected, sponsor_type == "Industry") |>
    mutate(sponsor_clean = canonical_sponsor(sponsor)) |>   # parent company, see R/07_extensions.R
    left_join(
      bm_pos |>
        filter(!group %in% CFG$primary_exclude_groups) |>
        select(nct_id, biomarker),
      by = "nct_id", relationship = "one-to-many"
    ) |>
    group_by(sponsor_clean) |>
    summarise(
      n_bm_trials   = n_distinct(nct_id),
      n_recent      = n_distinct(nct_id[start_year %in% recent]),
      top_biomarker = {
        tb <- sort(table(biomarker), decreasing = TRUE)
        if (length(tb)) names(tb)[1] else NA_character_
      },
      .groups = "drop"
    ) |>
    arrange(desc(n_bm_trials))

  # ---- 6. Phase mix ---------------------------------------------------------
  phase_mix <- trials |>
    mutate(selection = if_else(biomarker_selected, "Biomarker-selected", "Not selected")) |>
    count(selection, sponsor_type, phase) |>
    group_by(selection, sponsor_type) |>
    mutate(share = n / sum(n)) |>
    ungroup()

  # Overall growth of all oncology trials (reference for "excess" growth)
  overall_growth <- growth_by_key(mutate(trials, key = "All oncology trials"), "growth") |>
    bind_rows(growth_by_key(mutate(filter(trials, biomarker_selected),
                                   key = "Biomarker-selected trials"), "growth"))

  list(
    by_year = by_year, by_tumour = by_tumour, by_tumour_year = by_tumour_year,
    by_biomarker = by_biomarker, by_biomarker_year = by_biomarker_year,
    by_biomarker_negative = by_biomarker_negative,
    tumour_biomarker = tumour_biomarker, sponsors = sponsors,
    phase_mix = phase_mix, overall_growth = overall_growth
  )
}

write_tables <- function(tabs, trials) {
  for (nm in names(tabs)) {
    readr::write_csv(tabs[[nm]], file.path(CFG$out_dir, paste0("table_", nm, ".csv")))
  }
  trials |>
    select(nct_id, brief_title, start_year, status, phase, sponsor, sponsor_type,
           tumour_primary, tumour_category, conditions, biomarker_selected,
           biomarkers, bm_groups, n_biomarkers, negative_selection_only, evidence,
           enrollment, interventions,
           any_of(c("modalities", "novel_modality", "countries", "regions", "region_profile"))) |>
    readr::write_csv(file.path(CFG$out_dir, "trials_classified.csv"))
  message("  tables written to ", CFG$out_dir)
}
