# =============================================================================
# The biomarker-selected trial landscape — full pipeline (enhanced version)
#
# Run from the project folder (open biomarker-trial-landscape.Rproj, or
# setwd() to this folder), then:   source("run_all.R")
#
# First run downloads ~100k trials from ClinicalTrials.gov (roughly 5–15 min)
# and caches them in data/. Later runs reuse the cache. For a quick dry run set
# test_mode = TRUE in R/00_config.R. Unit tests: source("run_tests.R").
# Alternative runner with step-by-step caching: targets::tar_make() (_targets.R).
# =============================================================================

source("R/00_config.R")
source("R/01_fetch.R")
source("R/02_dictionaries.R")
source("R/03_classify.R")
source("R/04_analyse.R")
source("R/05_plots.R")
source("R/06_validation.R")
source("R/07_extensions.R")
source("R/08_sensitivity.R")
source("R/09_outcomes.R")
source("R/10_llm_crosscheck.R")
source("R/11_other_registries.R")
source("R/12_figures.R")

t0 <- Sys.time()

message("\n[1/8] Downloading trials")
raw    <- fetch_ctg()
trials <- prepare_trials(raw)

message("\n[2/8] Classifying biomarker selection")
bm     <- classify_biomarkers(trials)
trials <- bm$trials

message("\n[3/8] Assigning tumour types (", CFG$tumour_method, ")")
tu     <- classify_tumours(trials)
trials <- tu$trials
readr::write_csv(tu$agreement, file.path(CFG$out_dir, "tumour_text_vs_mesh_agreement.csv"))

message("\n[4/8] Drug types and geography")
mo     <- classify_modalities(trials)
trials <- mo$trials
ge     <- classify_geography(trials)
trials <- ge$trials
approvals <- load_approvals()

message("\n[5/8] Summarising")
tabs <- analyse_landscape(trials, tu$tumour_long, bm$bm_trial)
ext  <- analyse_extensions(trials, bm$bm_trial, mo$modality_long, ge$region_long, approvals)
write_tables(tabs, trials)
write_extension_tables(ext)

message("\n[6/8] Sensitivity analyses and outcomes")
sens <- run_sensitivity(trials, bm$bm_trial, tu$tumour_long)
readr::write_csv(sens$summary, file.path(CFG$out_dir, "sensitivity_summary.csv"))
readr::write_csv(sens$tumour,  file.path(CFG$out_dir, "sensitivity_by_tumour.csv"))
outc <- analyse_outcomes(trials)
write_outcome_tables(outc)

message("\n[7/8] Optional modules")
clear_figures()   # remove figures from earlier runs before anything is saved
llm <- if (CFG$run_llm_crosscheck) run_llm_crosscheck(trials) else {
  message("  LLM cross-check off (set CFG$run_llm_crosscheck <- TRUE and ANTHROPIC_API_KEY)"); NULL
}
reg <- analyse_other_registries(trials)

saveRDS(list(trials = trials, tumour_long = tu$tumour_long, bm_trial = bm$bm_trial,
             modality_long = mo$modality_long, region_long = ge$region_long,
             approvals = approvals, tumour_agreement = tu$agreement,
             tabs = tabs, ext = ext, sens = sens, outc = outc, llm = llm, reg = reg),
        file.path(CFG$data_dir, "landscape_results.rds"))
draw_validation_sample(trials)

message("\n[8/8] Plotting (curated set: see FIGURE_PLAN in R/00_config.R)")
make_main_figures(tabs, ext, sens)   # Figures 1 and 2 (multi-panel)
plot_outcomes(outc)                  # Figure 3 + supplementary
plot_sensitivity(sens)               # Figure 4
make_plots(tabs)                     # supplementary
make_extension_plots(ext, tabs)      # supplementary

# ---- Console summary --------------------------------------------------------
cat("\n================ SUMMARY ================\n")
cat(sprintf("Oncology treatment trials (%s–%s): %s\n",
            min(trials$start_year), max(trials$start_year),
            format(nrow(trials), big.mark = ",")))
cat(sprintf("Biomarker-selected: %s (%.1f%%)\n",
            format(sum(trials$biomarker_selected), big.mark = ","),
            100 * mean(trials$biomarker_selected)))
cat("\nSensitivity analyses:\n")
print(select(sens$summary, scenario, pct_all, pct_2005_09, pct_2021_25, tumour_rank_corr))
cat("\nTermination and results (odds ratios, biomarker-selected vs not):\n")
print(select(outc$effects, model, estimate, lo, hi))
cat(sprintf("\nDone in %.1f min. Outputs in ./%s\n",
            as.numeric(difftime(Sys.time(), t0, units = "mins")), CFG$out_dir))

# ---- Reports (need rmarkdown + pandoc; RStudio ships pandoc) -----------------
if (requireNamespace("rmarkdown", quietly = TRUE) && rmarkdown::pandoc_available()) {
  rmarkdown::render("report.Rmd", output_dir = CFG$out_dir, quiet = TRUE)
  rmarkdown::render("manuscript.Rmd", output_dir = CFG$out_dir, quiet = TRUE)
  message("Report: ", file.path(CFG$out_dir, "report.html"),
          "\nManuscript: ", file.path(CFG$out_dir, "manuscript.html"))
}
message("Dashboard: shiny::runApp(\"dashboard\")")
