# =============================================================================
# 10_llm_crosscheck.R — compare the regex classifier with a language model
#
# OPTIONAL. Needs an Anthropic API key:
#   Sys.setenv(ANTHROPIC_API_KEY = "sk-ant-...")   # or put it in ~/.Renviron
#   CFG$run_llm_crosscheck <- TRUE
# Cost: ~300 short requests with a small model (CFG$llm_model); results are
# cached in data/llm_crosscheck.rds, so re-running does not call the API again.
#
# The LLM is a second opinion, not ground truth. Use the disagreements to find
# regex errors, and still label the validation sample by hand.
# =============================================================================

LLM_PROMPT_VERSION <- "v1"

LLM_INSTRUCTIONS <- paste(
  "You are classifying a cancer clinical trial from its INCLUSION criteria.",
  "Question: does the trial require patients to have a specific tumour BIOMARKER status to enrol?",
  "Count it as biomarker-selected when inclusion requires a molecular or protein feature such as a",
  "mutation, fusion, amplification, overexpression or expression threshold (e.g. EGFR mutation,",
  "HER2-positive, ALK rearrangement, PD-L1 TPS >= 50%, MSI-H/dMMR, BRCA mutation, hormone-receptor",
  "positive, PSMA-positive, Claudin 18.2 positive, HLA-A*02:01).",
  "Do NOT count: a biomarker that is only tested or mentioned, prior therapy against a target,",
  "lineage antigens describing the disease (CD19, CD20, CD33, CD38, BCMA), or requirements that a",
  "biomarker be NEGATIVE/wild-type (record those as negative_only instead).",
  "Reply with JSON only, no other text:",
  '{"selected": true or false, "biomarkers": ["..."], "negative_only": true or false}'
)

llm_classify_one <- function(nct_id, inclusion, key, model) {
  prompt <- paste0(LLM_INSTRUCTIONS, "\n\nInclusion criteria:\n<<<\n",
                   str_trunc(coalesce(inclusion, ""), 6000), "\n>>>")
  resp <- request("https://api.anthropic.com/v1/messages") |>
    req_headers(`x-api-key` = key, `anthropic-version` = "2023-06-01") |>
    req_body_json(list(
      model      = model,
      max_tokens = 300,
      messages   = list(list(role = "user", content = prompt))
    )) |>
    req_retry(max_tries = 5,
              is_transient = function(r) resp_status(r) %in% c(429, 500, 502, 503, 529)) |>
    req_throttle(rate = 1) |>
    req_perform()
  txt    <- resp_body_json(resp)$content[[1]]$text
  js     <- str_extract(txt, "\\{[\\s\\S]*\\}")
  parsed <- tryCatch(jsonlite::fromJSON(js), error = function(e) NULL)
  tibble(
    nct_id            = nct_id,
    llm_selected      = if (is.null(parsed)) NA else isTRUE(parsed$selected),
    llm_negative_only = if (is.null(parsed)) NA else isTRUE(parsed$negative_only),
    llm_biomarkers    = if (is.null(parsed)) NA_character_ else paste(unlist(parsed$biomarkers), collapse = "; "),
    llm_raw           = txt
  )
}

run_llm_crosscheck <- function(trials) {
  key <- Sys.getenv("ANTHROPIC_API_KEY")
  if (!nzchar(key)) {
    message("  LLM cross-check skipped: ANTHROPIC_API_KEY is not set.")
    return(NULL)
  }
  cache <- file.path(CFG$data_dir, "llm_crosscheck.rds")
  done  <- if (file.exists(cache)) readRDS(cache) else tibble()

  set.seed(CFG$seed)
  n_each <- CFG$llm_sample_size %/% 2
  sample <- bind_rows(
    trials |> filter(biomarker_selected)  |> slice_sample(n = n_each),
    trials |> filter(!biomarker_selected) |> slice_sample(n = n_each)
  ) |>
    mutate(inclusion = split_inclusion(eligibility))

  todo <- filter(sample, !nct_id %in% done$nct_id)
  if (nrow(todo)) {
    message(sprintf("  Asking %s about %d trials...", CFG$llm_model, nrow(todo)))
    new <- purrr::map2_dfr(todo$nct_id, todo$inclusion, function(id, inc) {
      tryCatch(llm_classify_one(id, inc, key, CFG$llm_model),
               error = function(e) tibble(nct_id = id, llm_selected = NA, llm_raw = conditionMessage(e)))
    })
    done <- bind_rows(done, mutate(new, prompt_version = LLM_PROMPT_VERSION, model = CFG$llm_model))
    saveRDS(done, cache)
  }

  cmp <- sample |>
    select(nct_id, brief_title, biomarker_selected, biomarkers, evidence, inclusion) |>
    inner_join(done, by = "nct_id") |>
    filter(!is.na(llm_selected))

  a  <- cmp$biomarker_selected; b <- cmp$llm_selected
  po <- mean(a == b)
  pe <- mean(a) * mean(b) + (1 - mean(a)) * (1 - mean(b))
  summary <- tibble(
    n = nrow(cmp), agreement = po, kappa = (po - pe) / (1 - pe),
    both_selected = sum(a & b), regex_only = sum(a & !b), llm_only = sum(!a & b),
    neither = sum(!a & !b)
  )
  disagreements <- cmp |> filter(biomarker_selected != llm_selected) |>
    mutate(url = paste0("https://clinicaltrials.gov/study/", nct_id),
           inclusion = str_trunc(str_squish(inclusion), 1500))

  readr::write_csv(summary, file.path(CFG$out_dir, "llm_crosscheck_summary.csv"))
  readr::write_csv(disagreements, file.path(CFG$out_dir, "llm_crosscheck_disagreements.csv"))
  message(sprintf("  LLM vs regex: %.0f%% agreement, kappa %.2f (%d trials). Disagreements in output/llm_crosscheck_disagreements.csv",
                  100 * po, summary$kappa, nrow(cmp)))
  list(summary = summary, disagreements = disagreements, comparison = cmp)
}
