# =============================================================================
# 03_classify.R — detect biomarker selection and assign tumour types
#
# Biomarker selection logic
#   1. Take the INCLUSION part of the eligibility criteria (text before the
#      "Exclusion criteria" heading) plus the brief + official titles.
#   2. Split into criterion lines (bullets).
#   3. Find every biomarker mention, and read a short context window around it,
#      cut at commas / "and" / "or" so neighbouring biomarkers don't bleed in.
#   4. Context with "positive / mutation / amplified / >= ..." -> positive
#      selection; "negative / wild-type / < ..." -> negative selection;
#      otherwise a bare mention (e.g. "tissue for PD-L1 testing").
#   5. A trial is BIOMARKER-SELECTED if at least one biomarker (outside the
#      excluded groups) is positively selected.
# =============================================================================

split_inclusion <- function(elig) {
  str_split_fixed(
    coalesce(elig, ""),
    regex("exclusion criteria|key exclusion|exclusion:", ignore_case = TRUE),
    2
  )[, 1]
}

make_criterion_lines <- function(trials) {
  incl <- tibble(
    nct_id = trials$nct_id,
    source = "inclusion",
    text   = split_inclusion(trials$eligibility)
  ) |>
    separate_rows(text, sep = "\\n+")

  titles <- tibble(
    nct_id = trials$nct_id,
    source = "title",
    text   = paste(coalesce(trials$brief_title, ""), coalesce(trials$official_title, ""),
                   sep = " | ")
  )

  bind_rows(incl, titles) |>
    mutate(text = str_squish(text)) |>
    filter(nchar(text) > 2)
}

find_biomarker_mentions <- function(lines, dict = BIOMARKERS) {
  res <- purrr::pmap(dict, function(biomarker, group, pattern) {
    re  <- regex(pattern)
    hit <- str_detect(lines$text, re)
    if (!any(hit)) return(NULL)
    b   <- lines[hit, ]
    loc <- str_locate_all(b$text, re)
    n   <- map_int(loc, nrow)
    tibble(
      nct_id    = rep(b$nct_id, n),
      source    = rep(b$source, n),
      text      = rep(b$text, n),
      start     = unlist(map(loc, ~ .x[, "start"])),
      end       = unlist(map(loc, ~ .x[, "end"])),
      biomarker = biomarker,
      group     = group
    )
  })
  out <- bind_rows(res)
  if (nrow(out) == 0) {   # no biomarker mentioned anywhere: return an empty, well-formed table
    out <- tibble(nct_id = character(), source = character(), text = character(),
                  start = integer(), end = integer(), biomarker = character(), group = character())
  }
  out
}

score_mentions <- function(mentions) {
  mentions |>
    mutate(
      pre    = str_sub(text, pmax(1L, start - 30L), start - 1L),
      post   = str_sub(text, end + 1L, end + 45L),
      pre    = str_remove(pre,  regex(PRE_DELIM,  ignore_case = TRUE)),
      post   = str_remove(post, regex(POST_DELIM, ignore_case = TRUE)),
      ctx    = paste0(pre, str_sub(text, start, end), post),
      is_neg = str_detect(ctx, NEG_CTX),
      is_pos = str_detect(ctx, POS_CTX),
      is_neg = is_neg | (source == "inclusion" & str_detect(text, EXCL_LINE)),
      status = case_when(is_neg ~ "negative", is_pos ~ "positive", TRUE ~ "mention")
    )
}

classify_biomarkers <- function(trials) {
  message("Splitting eligibility criteria into lines...")
  lines <- make_criterion_lines(trials)
  message(sprintf("  %s criterion lines; scanning %d biomarker patterns...",
                  format(nrow(lines), big.mark = ","), nrow(BIOMARKERS)))
  mentions <- find_biomarker_mentions(lines) |> score_mentions()

  # One row per trial x biomarker: positive beats negative beats mention
  bm_trial <- mentions |>
    group_by(nct_id, biomarker, group) |>
    summarise(
      # 'status' is overwritten last, so the two lines above it still see the
      # per-mention statuses
      in_title = any(source == "title" & status == "positive"),
      in_inclusion = any(source == "inclusion" & status == "positive"),
      evidence = first(ctx[status == "positive"], default = first(ctx)),
      status   = case_when(any(status == "positive") ~ "positive",
                           any(status == "negative") ~ "negative",
                           TRUE                      ~ "mention"),
      .groups  = "drop"
    )

  selected <- bm_trial |>
    filter(status == "positive", !group %in% CFG$primary_exclude_groups) |>
    group_by(nct_id) |>
    summarise(
      biomarkers   = paste(sort(unique(biomarker)), collapse = "; "),
      bm_groups    = paste(sort(unique(group)), collapse = "; "),
      n_biomarkers = n_distinct(biomarker),
      evidence     = paste(unique(evidence), collapse = " || "),
      .groups      = "drop"
    )

  negative_only <- bm_trial |>
    filter(!group %in% CFG$primary_exclude_groups) |>
    group_by(nct_id) |>
    summarise(any_neg = any(status == "negative"), any_pos = any(status == "positive"),
              .groups = "drop") |>
    filter(any_neg, !any_pos) |>
    pull(nct_id)

  trials_out <- trials |>
    left_join(selected, by = "nct_id") |>
    mutate(
      biomarker_selected = !is.na(biomarkers),
      n_biomarkers       = coalesce(n_biomarkers, 0L),
      negative_selection_only = nct_id %in% negative_only
    )

  list(trials = trials_out, bm_trial = bm_trial, mentions = mentions)
}

# ---- Tumour types -------------------------------------------------------------
tumour_matrix <- function(txt, dict) {
  m <- vapply(dict$pattern, function(p) str_detect(txt, regex(p)), logical(length(txt)))
  matrix(m, nrow = length(txt), dimnames = list(NULL, dict$tumour))
}

# Cohen's kappa per tumour type: agreement between free-text and MeSH flags,
# among trials that have MeSH terms.
tumour_agreement <- function(m_text, m_mesh, has_mesh) {
  purrr::map_dfr(colnames(m_text), function(tu) {
    a <- m_text[has_mesh, tu]; b <- m_mesh[has_mesh, tu]
    po <- mean(a == b)
    pe <- mean(a) * mean(b) + (1 - mean(a)) * (1 - mean(b))
    tibble(tumour = tu, n_text = sum(a), n_mesh = sum(b), n_both = sum(a & b),
           agreement = po, kappa = if (pe < 1) (po - pe) / (1 - pe) else NA_real_)
  })
}

classify_tumours <- function(trials, method = CFG$tumour_method) {
  txt <- paste(coalesce(trials$conditions, ""), coalesce(trials$keywords, ""),
               coalesce(trials$brief_title, ""), sep = " | ")
  m_text <- tumour_matrix(txt, TUMOURS)

  # MeSH-based classification (falls back to free text when no MeSH term matches)
  mesh_txt <- coalesce(trials$mesh_terms, "")
  m_mesh   <- tumour_matrix(mesh_txt, MESH_TUMOURS[match(TUMOURS$tumour, MESH_TUMOURS$tumour), ])
  has_mesh <- rowSums(m_mesh) > 0
  agreement <- tumour_agreement(m_text, m_mesh, has_mesh)

  m <- switch(method,
    text       = m_text,
    union      = m_text | m_mesh,
    mesh_first = { mm <- m_text; mm[has_mesh, ] <- m_mesh[has_mesh, ]; mm },
    stop("CFG$tumour_method must be 'mesh_first', 'text' or 'union'")
  )
  pan        <- str_detect(coalesce(trials$conditions, ""), regex(PAN_TUMOUR_PATTERN)) |
                str_detect(coalesce(trials$brief_title, ""), regex(PAN_TUMOUR_PATTERN))
  n_specific <- rowSums(m)
  first_hit  <- TUMOURS$tumour[max.col(m * 1, ties.method = "first")]

  primary <- case_when(
    n_specific >= 4                  ~ "Pan-tumour / multiple",
    n_specific == 0 & pan            ~ "Pan-tumour / multiple",
    n_specific == 0                  ~ "Other / unspecified",
    TRUE                             ~ first_hit
  )

  # Long format: a trial counts toward each tumour it names (up to 3);
  # broader trials count once under "Pan-tumour / multiple".
  long_specific <- as_tibble(m) |>
    mutate(nct_id = trials$nct_id, n_specific = n_specific) |>
    filter(n_specific >= 1, n_specific <= 3) |>
    pivot_longer(-c(nct_id, n_specific), names_to = "tumour", values_to = "hit") |>
    filter(hit) |>
    select(nct_id, tumour)
  long_other <- tibble(nct_id = trials$nct_id, tumour = primary, n_specific = n_specific) |>
    filter(n_specific == 0 | n_specific >= 4) |>
    select(nct_id, tumour)

  cat_lookup <- c(setNames(TUMOURS$category, TUMOURS$tumour),
                  "Pan-tumour / multiple" = "Pan-tumour / multiple",
                  "Other / unspecified"   = "Other / unspecified")

  tumour_long <- bind_rows(long_specific, long_other) |>
    mutate(category = unname(cat_lookup[tumour]))

  list(
    agreement = agreement,
    trials = trials |>
      mutate(tumour_primary  = primary,
             tumour_category = unname(cat_lookup[primary]),
             n_tumour_types  = n_specific),
    tumour_long = tumour_long
  )
}
