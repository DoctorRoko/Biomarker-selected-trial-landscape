# =============================================================================
# One-time setup: record the exact package versions used (renv)
#
# Run once in a fresh R session from the project folder:
#   source("setup_renv.R")
# This creates renv.lock. Commit renv.lock (and the renv/ folder except
# renv/library) to GitHub. Anyone can then reproduce your environment with:
#   renv::restore()
# =============================================================================

if (!requireNamespace("renv", quietly = TRUE)) install.packages("renv")

renv::init(bare = TRUE, restart = FALSE)
renv::install(c(
  # pipeline
  "httr2", "jsonlite", "dplyr", "tidyr", "stringr", "purrr", "tibble", "readr",
  "ggplot2", "forcats", "scales", "ggrepel", "patchwork", "xml2",
  # report, tests, pipeline tooling
  "rmarkdown", "knitr", "testthat", "targets",
  # dashboard
  "shiny", "bslib", "DT", "shinyWidgets"
))
renv::snapshot(prompt = FALSE)
message("renv.lock written. Commit it to version control.")
