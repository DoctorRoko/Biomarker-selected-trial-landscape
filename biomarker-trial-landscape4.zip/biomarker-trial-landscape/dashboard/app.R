# =============================================================================
# Interactive dashboard for the biomarker-selected trial landscape
#
# Run the pipeline first (source("run_all.R")), then from the project folder:
#   shiny::runApp("dashboard")
# To share it online: copy data/landscape_results.rds into dashboard/ and run
#   rsconnect::deployApp("dashboard")   # shinyapps.io
# =============================================================================

for (p in c("shiny", "bslib", "DT", "shinyWidgets", "dplyr", "tidyr", "ggplot2", "readr",
            "scales", "stringr", "forcats")) {
  if (!requireNamespace(p, quietly = TRUE)) install.packages(p)
}
suppressPackageStartupMessages({
  library(shiny); library(bslib); library(DT); library(shinyWidgets); library(dplyr)
  library(tidyr); library(ggplot2); library(scales); library(stringr); library(forcats)
})

`%||%` <- function(x, y) if (is.null(x)) y else x

# ---- Data --------------------------------------------------------------------
rds <- c("landscape_results.rds", file.path("..", "data", "landscape_results.rds"),
         file.path("data", "landscape_results.rds"))
rds <- rds[file.exists(rds)][1]
if (is.na(rds)) stop("landscape_results.rds not found. Run source('run_all.R') first.")
res <- readRDS(rds)

# Start month of each trial (ClinicalTrials.gov dates are "2019-03" or "2019-03-15")
trials <- res$trials |>
  mutate(start_month = as.Date(paste0(substr(start_date, 1, 7), "-01"))) |>
  filter(!is.na(start_month))

bm_pos   <- res$bm_trial |> filter(status == "positive", group != "Haematologic lineage antigen")
tum_long <- res$tumour_long
mod_long <- res$modality_long %||% tibble(nct_id = character(), modality = character())
reg_long <- res$region_long   %||% tibble(nct_id = character(), region = character())

BLUE <- "#2a78d6"; ORANGE <- "#eb6834"; INK2 <- "#52514e"
SEQ  <- c("#cde2fb", "#9ec5f4", "#6da7ec", "#3987e5", "#256abf", "#184f95", "#0d366b")
REGION_COLS <- c("United States" = "#2a78d6", "China" = "#eb6834", "Europe" = "#1baf7a",
                 "Japan" = "#eda100", "Other Asia-Pacific" = "#e87ba4", "Rest of world" = "#008300")
sponsor_cols <- c(Industry = BLUE, `Non-industry` = ORANGE)
theme_dash <- theme_minimal(base_size = 13) +
  theme(panel.grid.minor = element_blank(), legend.position = "top",
        legend.justification = "left", plot.title = element_text(face = "bold"),
        plot.subtitle = element_text(colour = INK2))

choices_tumour    <- sort(unique(tum_long$tumour))
choices_biomarker <- bm_pos |> count(biomarker, sort = TRUE) |> pull(biomarker)
choices_region    <- intersect(names(REGION_COLS), unique(reg_long$region))
choices_modality  <- sort(setdiff(unique(mod_long$modality),
                                  c("Other / unclassified", "Procedure / device")))

# Month choices for the timeline slider: "Jan 2005" ... "Dec 2025"
months       <- seq(min(trials$start_month), max(trials$start_month), by = "month")
month_labels <- format(months, "%b %Y")

# ---- Time helpers -----------------------------------------------------------------
# Granularity: Auto picks months for spans up to 3 years, quarters up to 8, else years
pick_unit <- function(choice, from, to) {
  if (choice != "Auto") return(choice)
  span <- as.numeric(difftime(to, from, units = "days")) / 365.25
  if (span <= 3) "Month" else if (span <= 8) "Quarter" else "Year"
}
floor_period <- function(d, unit) {
  y <- as.integer(format(d, "%Y")); m <- as.integer(format(d, "%m"))
  switch(unit,
         Month   = as.Date(sprintf("%d-%02d-01", y, m)),
         Quarter = as.Date(sprintf("%d-%02d-01", y, (m - 1) %/% 3 * 3 + 1)),
         Year    = as.Date(sprintf("%d-01-01", y)))
}
period_axis <- function(unit) {
  switch(unit,
         Month   = scale_x_date(date_labels = "%b %Y", breaks = breaks_pretty(8)),
         Quarter = scale_x_date(labels = function(d) paste0(format(d, "%Y"), " Q", (as.integer(format(d, "%m")) - 1) %/% 3 + 1),
                                breaks = breaks_pretty(8)),
         Year    = scale_x_date(date_labels = "%Y", breaks = breaks_pretty(8)))
}
bar_width <- function(unit) switch(unit, Month = 25, Quarter = 75, Year = 300)

# ---- UI -----------------------------------------------------------------------------
ui <- page_sidebar(
  title = "The biomarker-selected oncology trial landscape",
  theme = bs_theme(version = 5, primary = BLUE, base_font = font_google("Inter")),
  sidebar = sidebar(
    width = 320,
    sliderTextInput("months", "Trial start (month and year)", choices = month_labels,
                    selected = c(month_labels[1], month_labels[length(month_labels)]),
                    grid = FALSE, force_edges = TRUE),
    radioButtons("unit", "Show trends by", c("Auto", "Year", "Quarter", "Month"),
                 selected = "Auto", inline = TRUE),
    selectizeInput("tumour", "Tumour type", choices_tumour, multiple = TRUE,
                   options = list(placeholder = "All tumour types")),
    selectizeInput("biomarker", "Biomarker (selected for)", choices_biomarker, multiple = TRUE,
                   options = list(placeholder = "Any biomarker")),
    selectizeInput("region", "Trial sites in", choices_region, multiple = TRUE,
                   options = list(placeholder = "Anywhere")),
    selectizeInput("modality", "Drug type tested", choices_modality, multiple = TRUE,
                   options = list(placeholder = "Any drug type")),
    checkboxGroupInput("sponsor", "Lead sponsor", c("Industry", "Non-industry"),
                       selected = c("Industry", "Non-industry"), inline = TRUE),
    actionLink("reset", "Reset all filters"),
    hr(),
    downloadButton("download", "Download filtered trials (CSV)", class = "btn-sm")
  ),
  layout_columns(
    fill = FALSE,
    value_box("Oncology trials", textOutput("n_all"), p(textOutput("range_lab", inline = TRUE)), theme = "light"),
    value_box("Biomarker-selected", textOutput("n_bm"), theme = "primary"),
    value_box("Share selected", textOutput("pct_bm"), theme = "light"),
    value_box("Industry-led (selected)", textOutput("pct_ind"), theme = "light")
  ),
  navset_card_underline(
    nav_panel("Trend",
              layout_columns(plotOutput("p_counts", height = 400), plotOutput("p_share", height = 400))),
    nav_panel("Tumour × biomarker", plotOutput("p_heat", height = 580)),
    nav_panel("Investment map", plotOutput("p_invest", height = 580)),
    nav_panel("Regions", plotOutput("p_regions", height = 480)),
    nav_panel("Sponsors", plotOutput("p_sponsors", height = 580)),
    nav_panel("Trials", DTOutput("tbl")),
    nav_panel("About",
              markdown(paste(
                "**Data.** Interventional oncology treatment trials registered on ClinicalTrials.gov,",
                "started 2005–2025.",
                "",
                "**Biomarker-selected** means the inclusion criteria (or title) require a positive biomarker",
                "status, e.g. *EGFR mutation*, *HER2-positive*, *PD-L1 ≥ 50%*. Mentions without selection",
                "(\"tissue for PD-L1 testing\") and negative selection (\"RAS wild-type\") do not count.",
                "Lineage antigens such as CD19 or CD20 are excluded.",
                "",
                "**Tumour types** come from MeSH terms (free text as fallback); a trial naming up to three",
                "tumour types counts in each. **Drug types** describe what is tested in experimental arms.",
                "**Regions** count trials with at least one site in the region.",
                "",
                "**Caveat.** Classification is automated text mining and will contain errors; registry",
                "activity is a proxy for investment, not funding data.",
                sep = "\n")))
  )
)

# ---- Server ----------------------------------------------------------------------------
server <- function(input, output, session) {

  observeEvent(input$reset, {
    updateSliderTextInput(session, "months", selected = c(month_labels[1], month_labels[length(month_labels)]))
    updateRadioButtons(session, "unit", selected = "Auto")
    for (id in c("tumour", "biomarker", "region", "modality")) updateSelectizeInput(session, id, selected = character(0))
    updateCheckboxGroupInput(session, "sponsor", selected = c("Industry", "Non-industry"))
  })

  date_range <- reactive({
    sel <- match(input$months, month_labels)
    c(months[min(sel)], months[max(sel)])
  })
  unit <- reactive(pick_unit(input$unit, date_range()[1], date_range()[2]))

  # All trials matching the non-biomarker filters (the denominator)
  base <- reactive({
    r <- date_range()
    d <- trials |>
      filter(start_month >= r[1], start_month <= r[2], sponsor_type %in% input$sponsor)
    if (length(input$tumour))   d <- filter(d, nct_id %in% tum_long$nct_id[tum_long$tumour %in% input$tumour])
    if (length(input$region))   d <- filter(d, nct_id %in% reg_long$nct_id[reg_long$region %in% input$region])
    if (length(input$modality)) d <- filter(d, nct_id %in% mod_long$nct_id[mod_long$modality %in% input$modality])
    mutate(d, period = floor_period(start_month, unit()))
  })

  # Which of those count as "selected" (optionally for specific biomarkers)
  flagged <- reactive({
    d <- base()
    if (length(input$biomarker)) {
      mutate(d, sel = nct_id %in% bm_pos$nct_id[bm_pos$biomarker %in% input$biomarker])
    } else {
      mutate(d, sel = biomarker_selected)
    }
  })

  output$range_lab <- renderText(paste(format(date_range(), "%b %Y"), collapse = " – "))
  output$n_all   <- renderText(comma(nrow(base())))
  output$n_bm    <- renderText(comma(sum(flagged()$sel)))
  output$pct_bm  <- renderText(if (nrow(base())) percent(mean(flagged()$sel), accuracy = 0.1) else "–")
  output$pct_ind <- renderText({
    s <- filter(flagged(), sel)
    if (nrow(s)) percent(mean(s$sponsor_type == "Industry"), accuracy = 1) else "–"
  })

  per_lab <- reactive(tolower(unit()))

  output$p_counts <- renderPlot({
    d <- flagged() |> filter(sel) |> count(period, sponsor_type)
    validate(need(nrow(d) > 0, "No biomarker-selected trials match these filters."))
    ggplot(d, aes(period, n, fill = sponsor_type)) +
      geom_col(width = bar_width(unit()), colour = "white", linewidth = 0.2) +
      scale_fill_manual(values = sponsor_cols, name = NULL) +
      period_axis(unit()) +
      labs(title = "Biomarker-selected trial starts", subtitle = paste("Per", per_lab()),
           x = NULL, y = "Trials") + theme_dash
  })

  output$p_share <- renderPlot({
    d <- flagged() |> group_by(period) |> summarise(n = n(), k = sum(sel), .groups = "drop") |>
      mutate(p = k / n,
             lo = (p + 1.92 / n - 1.96 * sqrt(p * (1 - p) / n + 0.96 / n^2)) / (1 + 3.84 / n),
             hi = (p + 1.92 / n + 1.96 * sqrt(p * (1 - p) / n + 0.96 / n^2)) / (1 + 3.84 / n))
    validate(need(nrow(d) > 0, "No trials match these filters."))
    ggplot(d, aes(period, p)) +
      geom_ribbon(aes(ymin = lo, ymax = hi), fill = SEQ[2], alpha = 0.6) +
      geom_line(colour = BLUE, linewidth = 1) + geom_point(colour = BLUE, size = 1.4) +
      period_axis(unit()) +
      scale_y_continuous(labels = percent, limits = c(0, NA)) +
      labs(title = "Share of trials that are biomarker-selected",
           subtitle = paste("Per", per_lab(), "with 95% CI"), x = NULL, y = NULL) + theme_dash
  })

  output$p_heat <- renderPlot({
    ids <- filter(flagged(), sel)$nct_id
    d <- bm_pos |> filter(nct_id %in% ids) |>
      inner_join(tum_long, by = "nct_id", relationship = "many-to-many") |>
      count(tumour, biomarker)
    validate(need(nrow(d) > 0, "No biomarker-selected trials match these filters."))
    top_b <- d |> count(biomarker, wt = n, sort = TRUE) |> head(15) |> pull(biomarker)
    top_t <- d |> count(tumour, wt = n, sort = TRUE) |> head(16) |> pull(tumour)
    d <- d |> filter(biomarker %in% top_b, tumour %in% top_t) |>
      mutate(biomarker = factor(biomarker, top_b), tumour = factor(tumour, rev(top_t)))
    ggplot(d, aes(biomarker, tumour, fill = n)) +
      geom_tile(colour = "white") +
      geom_text(aes(label = n, colour = n > quantile(n, 0.8)), size = 3.4, show.legend = FALSE) +
      scale_colour_manual(values = c(`TRUE` = "white", `FALSE` = "black")) +
      scale_fill_gradientn(colours = SEQ, trans = "log10", name = "Trials") +
      labs(x = NULL, y = NULL) + theme_dash +
      theme(axis.text.x = element_text(angle = 40, hjust = 1), panel.grid = element_blank(),
            legend.position = "right")
  })

  output$p_invest <- renderPlot({
    s <- filter(flagged(), sel)
    recent_from <- seq(date_range()[2], by = "-5 years", length.out = 2)[2]
    d <- tum_long |> filter(nct_id %in% s$nct_id) |>
      inner_join(select(s, nct_id, sponsor_type, start_month), by = "nct_id") |>
      group_by(tumour) |>
      summarise(n = n(), industry = mean(sponsor_type == "Industry"),
                recent = mean(start_month > recent_from), .groups = "drop") |>
      filter(n >= 10)
    validate(need(nrow(d) > 0, "Too few trials for the investment map (needs 10+ per tumour)."))
    ggplot(d, aes(industry, recent, size = n)) +
      geom_point(colour = BLUE, alpha = 0.75) +
      geom_text(aes(label = tumour), size = 3.6, vjust = -1.2, colour = "black", check_overlap = TRUE) +
      scale_size_area(max_size = 16, name = "Trials") +
      scale_x_continuous(labels = percent) + scale_y_continuous(labels = percent) +
      labs(title = "Industry share vs momentum",
           subtitle = sprintf("Momentum = share of the tumour's biomarker trials started after %s",
                              format(recent_from, "%b %Y")),
           x = "Industry-led share", y = "Started in the last 5 years of the range") + theme_dash
  })

  output$p_regions <- renderPlot({
    s <- filter(flagged(), sel, nct_id %in% reg_long$nct_id)
    d <- reg_long |> filter(nct_id %in% s$nct_id) |>
      inner_join(select(s, nct_id, period), by = "nct_id") |>
      count(region, period) |>
      left_join(count(s, period, name = "tot"), by = "period") |>
      mutate(share = n / tot, region = factor(region, names(REGION_COLS)))
    validate(need(nrow(d) > 0, "No trials with listed sites match these filters."))
    ggplot(d, aes(period, share, colour = region)) + geom_line(linewidth = 1) +
      scale_colour_manual(values = REGION_COLS, name = NULL) +
      period_axis(unit()) +
      scale_y_continuous(labels = percent, limits = c(0, NA)) +
      labs(title = "Share of biomarker-selected trials with a site in each region",
           subtitle = paste("Per", per_lab()), x = NULL, y = NULL) + theme_dash
  })

  output$p_sponsors <- renderPlot({
    d <- filter(flagged(), sel, sponsor_type == "Industry") |>
      count(sponsor, sort = TRUE) |> head(20) |>
      mutate(sponsor = fct_reorder(str_trunc(sponsor, 40), n))
    validate(need(nrow(d) > 0, "No industry-sponsored trials match these filters."))
    ggplot(d, aes(n, sponsor)) + geom_col(fill = BLUE, width = 0.7) +
      geom_text(aes(label = n), hjust = -0.2, size = 3.6, colour = INK2) +
      scale_x_continuous(expand = expansion(c(0, 0.1))) +
      labs(title = "Top industry lead sponsors", x = "Biomarker-selected trials", y = NULL) + theme_dash
  })

  table_data <- reactive({
    filter(flagged(), sel) |>
      transmute(NCT = nct_id, Title = brief_title, Start = format(start_month, "%b %Y"),
                Phase = as.character(phase), Status = status, Sponsor = sponsor,
                Tumour = tumour_primary, Biomarkers = biomarkers,
                `Drug types` = if ("modalities" %in% names(trials)) modalities else NA_character_,
                Regions = if ("regions" %in% names(trials)) regions else NA_character_,
                Evidence = evidence)
  })

  output$tbl <- renderDT({
    d <- table_data() |>
      mutate(NCT = sprintf('<a href="https://clinicaltrials.gov/study/%s" target="_blank">%s</a>', NCT, NCT),
             Evidence = str_trunc(Evidence, 160))
    datatable(d, escape = FALSE, rownames = FALSE, filter = "top",
              options = list(pageLength = 15, scrollX = TRUE))
  })

  output$download <- downloadHandler(
    filename = function() paste0("biomarker_trials_", format(Sys.Date(), "%Y%m%d"), ".csv"),
    content  = function(file) readr::write_csv(table_data(), file)
  )
}

shinyApp(ui, server)
