# =============================================================================
# 11_other_registries.R — is the "China surge" real or a registration shift?
#
# OPTIONAL. Many Chinese trials are registered only on ChiCTR (Chinese Clinical
# Trial Registry), which has no public API. The WHO International Clinical
# Trials Registry Platform (ICTRP) collects ChiCTR and other registries:
#   1. Go to https://trialsearch.who.int, search conditions such as
#      "cancer OR neoplasm OR carcinoma OR lymphoma OR leukaemia".
#   2. Export the results (CSV or XML) and save as data/ictrp_export.csv
#      (or .xml; set CFG$ictrp_file).
# This script then classifies those trials with the SAME biomarker rules and
# compares ChiCTR-only trials with ClinicalTrials.gov trials that have Chinese sites.
# Column names in ICTRP exports vary, so columns are matched loosely.
# =============================================================================

norm_name <- function(x) tolower(gsub("[^A-Za-z0-9]", "", x))

pick_col <- function(df, candidates) {
  nm  <- norm_name(names(df))
  hit <- match(norm_name(candidates), nm)
  hit <- hit[!is.na(hit)]
  if (length(hit) == 0) return(rep(NA_character_, nrow(df)))
  as.character(df[[hit[1]]])
}

read_ictrp <- function(path = CFG$ictrp_file) {
  if (!file.exists(path)) {
    xml_path <- sub("\\.csv$", ".xml", path)
    if (file.exists(xml_path)) path <- xml_path else return(NULL)
  }
  if (grepl("\\.xml$", path, ignore.case = TRUE)) {
    if (!requireNamespace("xml2", quietly = TRUE)) install.packages("xml2")
    doc    <- xml2::read_xml(path)
    trials <- xml2::xml_find_all(doc, "//Trial")
    raw <- purrr::map_dfr(trials, function(t) {
      kids <- xml2::xml_children(t)
      as_tibble(as.list(setNames(xml2::xml_text(kids), xml2::xml_name(kids))), .name_repair = "unique")
    })
  } else {
    raw <- readr::read_csv(path, show_col_types = FALSE, col_types = readr::cols(.default = "c"))
  }

  tibble(
    trial_id       = pick_col(raw, c("TrialID", "Trial ID", "Main ID")),
    source         = pick_col(raw, c("Source_Register", "Source Register", "Register")),
    brief_title    = pick_col(raw, c("Public_title", "Public title")),
    official_title = pick_col(raw, c("Scientific_title", "Scientific title")),
    study_type     = pick_col(raw, c("Study_type", "Study type")),
    date_start     = pick_col(raw, c("Date_enrollement", "Date enrollement", "Date_enrolment", "Date of first enrolment")),
    date_reg       = pick_col(raw, c("Date_registration", "Date registration", "Date_registration3")),
    countries      = pick_col(raw, c("Countries", "Country")),
    conditions     = pick_col(raw, c("Condition", "Conditions", "Health condition(s) or problem(s) studied")),
    inclusion      = pick_col(raw, c("Inclusion_Criteria", "Inclusion Criteria", "Inclusion_criteria")),
    secondary_ids  = pick_col(raw, c("Secondary_IDs", "Secondary IDs", "SecondaryIDs")),
    sponsor        = pick_col(raw, c("Primary_sponsor", "Primary sponsor"))
  ) |>
    mutate(
      year = suppressWarnings(as.integer(coalesce(str_extract(date_start, "(19|20)\\d{2}"),
                                                  str_extract(date_reg, "(19|20)\\d{2}"))))
    )
}

analyse_other_registries <- function(trials) {
  ict <- read_ictrp()
  if (is.null(ict)) {
    message("  Other-registry comparison skipped: no ICTRP export at ", CFG$ictrp_file)
    return(NULL)
  }
  yrs <- min(trials$start_year):max(trials$start_year)

  chictr <- ict |>
    filter(str_detect(coalesce(source, trial_id), regex("chictr", ignore_case = TRUE)),
           is.na(study_type) | str_detect(study_type, regex("interventional", ignore_case = TRUE)),
           year %in% yrs) |>
    # Drop ChiCTR records that are also on ClinicalTrials.gov (avoid double counting)
    filter(!str_detect(paste(coalesce(secondary_ids, ""), coalesce(official_title, "")), "NCT\\d{8}")) |>
    distinct(trial_id, .keep_all = TRUE)

  # Same biomarker classifier as for ClinicalTrials.gov
  as_ctg <- chictr |>
    transmute(nct_id = trial_id, brief_title, official_title,
              eligibility = coalesce(inclusion, ""))
  cls <- classify_biomarkers(as_ctg)
  chictr <- chictr |>
    left_join(select(cls$trials, nct_id, biomarker_selected, biomarkers),
              by = c("trial_id" = "nct_id"))

  ctg_china <- trials |>
    filter(str_detect(coalesce(regions, ""), "China")) |>
    mutate(group = if_else(region_profile == "China only",
                           "ClinicalTrials.gov, China-only sites",
                           "ClinicalTrials.gov, China + other regions"))

  by_year <- bind_rows(
    ctg_china |> transmute(group, year = start_year, biomarker_selected),
    chictr    |> transmute(group = "ChiCTR only (via WHO ICTRP)", year, biomarker_selected)
  ) |>
    group_by(group, year) |>
    summarise(n_trials = n(), n_bm = sum(biomarker_selected, na.rm = TRUE),
              pct_bm = n_bm / n_trials, .groups = "drop")

  readr::write_csv(by_year, file.path(CFG$out_dir, "registries_china_by_year.csv"))
  readr::write_csv(select(chictr, trial_id, year, brief_title, biomarker_selected, biomarkers),
                   file.path(CFG$out_dir, "registries_chictr_classified.csv"))

  p <- ggplot(by_year, aes(year, n_bm, colour = group)) +
    geom_line(linewidth = 0.8) + geom_point(size = 1.5) +
    scale_colour_manual(values = c("ClinicalTrials.gov, China-only sites" = PAL$industry,
                                   "ClinicalTrials.gov, China + other regions" = PAL$accent,
                                   "ChiCTR only (via WHO ICTRP)" = PAL$non_industry),
                        name = NULL) +
    scale_x_continuous(breaks = scales::breaks_width(2)) +
    labs(title = "Biomarker-selected trials in China, by registry",
         subtitle = "If ChiCTR-only trials rise too, the China trend is real growth, not just a shift in where trials register",
         x = "Start year", y = "Biomarker-selected trials", caption = "Sources: ClinicalTrials.gov API v2; WHO ICTRP export (ChiCTR records not cross-registered on ClinicalTrials.gov).") +
    theme_landscape() + theme(legend.direction = "vertical")
  save_fig(p, "fig27_registries_china", width = 9.5, height = 5.5)

  list(by_year = by_year, chictr = chictr)
}
