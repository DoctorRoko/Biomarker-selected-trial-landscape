# Unit tests for the text-mining rules. Run from the project root with
#   source("run_tests.R")
# Add a test every time you find (and fix) a misclassification.

test_that("neighbouring biomarkers with opposite status are separated", {
  s <- bm_status("Histologically confirmed HR-positive, HER2-negative advanced breast cancer")
  expect_equal(s[["ER/PR (hormone receptor)"]], "positive")
  expect_equal(s[["HER2 (ERBB2)"]], "negative")

  s <- bm_status("HR+/HER2- metastatic breast cancer")
  expect_equal(s[["HER2 (ERBB2)"]], "negative")
})

test_that("positive selection is detected", {
  expect_equal(bm_status("Documented EGFR mutation (exon 19 deletion or L858R)")[["EGFR"]], "positive")
  expect_equal(bm_status("Tumour must harbour an activating EGFR mutation")[["EGFR"]], "positive")
  expect_equal(bm_status("PD-L1 tumour proportion score (TPS) >= 50%")[["PD-L1"]], "positive")
  expect_equal(bm_status("MSI-H or dMMR solid tumours")[["MSI-H / dMMR"]], "positive")
  expect_equal(bm_status("BRAF V600E mutation confirmed by local test")[["BRAF"]], "positive")
  expect_equal(bm_status("Philadelphia chromosome-positive (Ph+) ALL")[["BCR::ABL1 / Ph+"]], "positive")
  expect_equal(bm_status("Germline BRCA1/2 mutation")[["BRCA / HRR / HRD"]], "positive")
  expect_equal(bm_status("HER2-low breast cancer (IHC 1+ or 2+/ISH-)")[["HER2 (ERBB2)"]], "positive")
})

test_that("negative selection is detected", {
  expect_equal(bm_status("RAS wild-type metastatic colorectal cancer")[["RAS (KRAS/NRAS)"]], "negative")
  expect_equal(bm_status("Microsatellite stable (MSS) colorectal cancer")[["MSI-H / dMMR"]], "negative")
  expect_equal(bm_status("Patients with known EGFR mutation or ALK rearrangement are not eligible")[["EGFR"]], "negative")
})

test_that("mere mentions are not selection", {
  expect_equal(bm_status("Tissue sample available for PD-L1 testing")[["PD-L1"]], "mention")
  expect_equal(bm_status("Prior anti-EGFR therapy allowed")[["EGFR"]], "mention")
  expect_length(bm_status("Patients must have met all eligibility criteria"), 0)
})

test_that("biomarkers in the exclusion criteria are ignored", {
  t <- tibble(nct_id = "NCT00000002", brief_title = "A study", official_title = NA_character_,
              eligibility = "Inclusion Criteria:\n\n* Advanced NSCLC\n\nExclusion Criteria:\n\n* EGFR mutation-positive disease")
  res <- suppressMessages(classify_biomarkers(t))
  expect_false(res$trials$biomarker_selected)
})

test_that("drug types are classified with the right priority", {
  expect_equal(drug_type("Trastuzumab deruxtecan"), "Antibody-drug conjugate")
  expect_equal(drug_type("Trastuzumab"), "Monoclonal antibody (other)")
  expect_equal(drug_type("Pembrolizumab"), "Checkpoint inhibitor")
  expect_equal(drug_type("Osimertinib"), "Targeted small molecule")
  expect_equal(drug_type("[177Lu]Lu-PSMA-617"), "Radioligand / radionuclide")
  expect_equal(drug_type("Axicabtagene ciloleucel"), "Cell therapy")
  expect_equal(drug_type("Tarlatamab"), "Bispecific / T-cell engager")
  expect_equal(drug_type("Paclitaxel"), "Chemotherapy")
  expect_equal(drug_type("Placebo"), "Placebo / control")
})

test_that("tumour types are assigned from MeSH terms and free text", {
  t <- tibble(nct_id = c("A", "B", "C"),
              conditions = c("Non-small Cell Lung Cancer", "Leukemia", "Solid Tumor"),
              keywords = NA_character_, brief_title = c("x", "x", "x"),
              mesh_terms = c("Carcinoma, Non-Small-Cell Lung", "Leukemia, Myeloid, Acute", NA))
  res <- classify_tumours(t, method = "mesh_first")$trials
  expect_equal(res$tumour_primary, c("Lung", "Acute myeloid leukaemia", "Pan-tumour / multiple"))
})

test_that("stop reasons are categorised", {
  expect_equal(classify_stop_reason("Slow accrual"), "Accrual / enrolment")
  expect_equal(classify_stop_reason("Futility at interim analysis"), "Efficacy / futility")
  expect_equal(classify_stop_reason("Sponsor business decision"), "Business / strategic")
  expect_equal(classify_stop_reason(NA), "Not stated")
})
