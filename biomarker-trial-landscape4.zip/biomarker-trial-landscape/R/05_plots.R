# =============================================================================
# 05_plots.R — figures (PNG, written to output/figures)
# =============================================================================

sponsor_fill <- scale_fill_manual(
  values = c("Industry" = PAL$industry, "Non-industry" = PAL$non_industry),
  name = "Lead sponsor"
)

category_colour <- c("Solid" = PAL$industry, "Haematological" = PAL$non_industry,
                     "Pan-tumour / multiple" = PAL$accent, "Other / unspecified" = PAL$ink2)

make_plots <- function(tabs) {
  yr_lab  <- sprintf("%d–%d", CFG$growth_years[1], CFG$growth_years[2])
  plots   <- list()

  # ---- 1. Biomarker-selected trial starts per year, by sponsor --------------
  d1 <- tabs$by_year |>
    select(start_year, Industry = n_bm_industry, `Non-industry` = n_bm_nonind) |>
    pivot_longer(-start_year, names_to = "sponsor_type", values_to = "n")
  plots$fig1_trend_counts <- ggplot(d1, aes(start_year, n, fill = sponsor_type)) +
    geom_col(width = 0.8, colour = "white", linewidth = 0.4) +
    sponsor_fill +
    scale_x_continuous(breaks = scales::breaks_width(2)) +
    scale_y_continuous(labels = scales::label_comma(), expand = expansion(c(0, 0.05))) +
    labs(title = "Biomarker-selected oncology trials started each year",
         subtitle = "Interventional treatment trials whose inclusion criteria or title select patients by a biomarker",
         x = "Start year", y = "Trials", caption = SOURCE_CAPTION) +
    theme_landscape()

  # ---- 2. Share of all oncology trials -------------------------------------
  plots$fig2_trend_share <- ggplot(tabs$by_year, aes(start_year, pct_bm)) +
    geom_ribbon(aes(ymin = pct_bm_lo, ymax = pct_bm_hi), fill = PAL$seq[2], alpha = 0.6) +
    geom_line(colour = PAL$industry, linewidth = 0.8) +
    geom_point(colour = PAL$industry, size = 2.2) +
    scale_x_continuous(breaks = scales::breaks_width(2)) +
    scale_y_continuous(labels = scales::label_percent(accuracy = 1), limits = c(0, NA),
                       expand = expansion(c(0, 0.08))) +
    labs(title = "Share of oncology trials that select patients by biomarker",
         subtitle = "Normalises for the overall growth of trial registrations; band = 95% Wilson CI",
         x = "Start year", y = "Share of oncology treatment trials", caption = SOURCE_CAPTION) +
    theme_landscape()

  # ---- 3. Tumour types --------------------------------------------------------
  d3 <- tabs$by_tumour |>
    filter(tumour != "Other / unspecified", n_bm > 0) |>
    mutate(Industry = round(n_bm * coalesce(bm_industry_share, 0)),
           `Non-industry` = n_bm - Industry,
           tumour = fct_reorder(tumour, n_bm))
  d3_long <- d3 |>
    select(tumour, Industry, `Non-industry`) |>
    pivot_longer(-tumour, names_to = "sponsor_type", values_to = "n")
  plots$fig3_tumour_types <- ggplot(d3_long, aes(n, tumour, fill = sponsor_type)) +
    geom_col(width = 0.75, colour = "white", linewidth = 0.4) +
    geom_text(data = d3, aes(x = n_bm, y = tumour,
                             label = sprintf("%s  (%.0f%% of trials)",
                                             scales::comma(n_bm), 100 * pct_bm)),
              inherit.aes = FALSE, hjust = -0.08, size = 3, colour = PAL$ink2) +
    sponsor_fill +
    scale_x_continuous(labels = scales::label_comma(), expand = expansion(c(0, 0.28))) +
    labs(title = "Biomarker-selected trials by tumour type",
         subtitle = "A trial naming up to three tumour types counts toward each; broader trials count as pan-tumour",
         x = "Biomarker-selected trials", y = NULL, caption = SOURCE_CAPTION) +
    theme_landscape()

  # ---- 4. Tumour x biomarker heatmap -----------------------------------------
  top_bm <- tabs$by_biomarker |> filter(in_headline) |> slice_max(n_trials, n = 15) |> pull(biomarker)
  top_tu <- tabs$by_tumour |> filter(tumour != "Other / unspecified") |>
    slice_max(n_bm, n = 16) |> pull(tumour)
  d4 <- tabs$tumour_biomarker |>
    filter(biomarker %in% top_bm, tumour %in% top_tu) |>
    complete(tumour = top_tu, biomarker = top_bm, fill = list(n_trials = 0L)) |>
    mutate(tumour    = factor(tumour, levels = rev(top_tu)),
           biomarker = factor(biomarker, levels = top_bm))
  plots$fig4_heatmap <- ggplot(d4, aes(biomarker, tumour, fill = n_trials)) +
    geom_tile(colour = "white", linewidth = 0.6) +
    geom_text(aes(label = ifelse(n_trials > 0, scales::comma(n_trials), ""),
                  colour = n_trials > stats::quantile(n_trials[n_trials > 0], 0.75)),
              size = 2.7, show.legend = FALSE) +
    scale_colour_manual(values = c(`TRUE` = "white", `FALSE` = PAL$ink)) +
    scale_fill_gradientn(colours = PAL$seq, trans = "log1p", na.value = "#f4f4f2",
                         breaks = c(0, 10, 100, 1000), labels = scales::label_comma(),
                         name = "Trials") +
    labs(title = "Which biomarkers are used in which tumours",
         subtitle = "Number of trials positively selecting for each biomarker",
         x = NULL, y = NULL, caption = SOURCE_CAPTION) +
    theme_landscape() +
    theme(axis.text.x = element_text(angle = 40, hjust = 1), panel.grid = element_blank(),
          legend.position = "right")

  # ---- 5. Biomarker trends (small multiples) ---------------------------------
  top12 <- head(top_bm, 12)
  d5 <- tabs$by_biomarker_year |>
    filter(biomarker %in% top12) |>
    complete(biomarker, start_year = min(tabs$by_year$start_year):max(tabs$by_year$start_year),
             fill = list(n_trials = 0L)) |>
    mutate(biomarker = factor(biomarker, levels = top12))
  plots$fig5_biomarker_trends <- ggplot(d5, aes(start_year, n_trials)) +
    geom_area(fill = PAL$seq[2], alpha = 0.6) +
    geom_line(colour = PAL$industry, linewidth = 0.7) +
    facet_wrap(~ biomarker, scales = "free_y", ncol = 4) +
    scale_x_continuous(breaks = scales::breaks_width(5)) +
    scale_y_continuous(limits = c(0, NA), expand = expansion(c(0, 0.08))) +
    labs(title = "Trial starts per year for the 12 most used biomarkers",
         subtitle = "Each panel has its own y-axis",
         x = "Start year", y = "Trials", caption = SOURCE_CAPTION) +
    theme_landscape(10)

  # ---- 6. Share selected over time, per tumour --------------------------------
  top_tu9 <- head(top_tu[top_tu != "Pan-tumour / multiple"], 12)
  d6 <- tabs$by_tumour_year |>
    filter(tumour %in% top_tu9) |>
    mutate(tumour = factor(tumour, levels = top_tu9))
  plots$fig6_tumour_share_trends <- ggplot(d6, aes(start_year, pct_bm)) +
    geom_ribbon(aes(ymin = pct_bm_lo, ymax = pct_bm_hi), fill = PAL$seq[2], alpha = 0.5) +
    geom_line(colour = PAL$industry, linewidth = 0.7) +
    geom_point(colour = PAL$industry, size = 1.2) +
    facet_wrap(~ tumour, ncol = 4) +
    scale_y_continuous(labels = scales::label_percent(accuracy = 1), limits = c(0, NA)) +
    scale_x_continuous(breaks = scales::breaks_width(5)) +
    labs(title = "How biomarker selection is spreading within each tumour type",
         subtitle = "Share of that tumour's treatment trials that are biomarker-selected; band = 95% CI",
         x = "Start year", y = "Share biomarker-selected", caption = SOURCE_CAPTION) +
    theme_landscape(10)

  # ---- 7. Investment map: tumour types ---------------------------------------
  ref <- tabs$overall_growth |> filter(key == "All oncology trials") |> pull(growth)
  d7 <- tabs$by_tumour |> filter(!is.na(bm_growth), tumour != "Other / unspecified")
  plots$fig7_investment_tumour <- ggplot(d7, aes(bm_industry_share, bm_growth)) +
    geom_hline(yintercept = ref, linetype = "dashed", colour = PAL$ink2, linewidth = 0.4) +
    annotate("text", x = min(d7$bm_industry_share, na.rm = TRUE), y = ref,
             label = "growth of all oncology trials", vjust = -0.6, hjust = 0,
             size = 3, colour = PAL$ink2) +
    geom_errorbar(aes(ymin = bm_growth_lo, ymax = bm_growth_hi, colour = category),
                  width = 0, linewidth = 0.4, alpha = 0.6) +
    geom_point(aes(size = n_bm, colour = category, shape = small_n), alpha = 0.85, stroke = 0.9) +
    scale_shape_manual(values = c(`FALSE` = 16, `TRUE` = 1),
                       labels = c(`FALSE` = sprintf("%d+ trials", SMALL_N),
                                  `TRUE` = sprintf("< %d trials (interpret with care)", SMALL_N)),
                       name = NULL) +
    ggrepel::geom_text_repel(aes(label = tumour), size = 3, colour = PAL$ink,
                             min.segment.length = 0.2, seed = CFG$seed) +
    scale_colour_manual(values = category_colour, name = NULL) +
    scale_size_area(max_size = 14, name = "Biomarker-selected trials",
                    labels = scales::label_comma()) +
    scale_x_continuous(labels = scales::label_percent(accuracy = 1)) +
    scale_y_continuous(labels = scales::label_percent(accuracy = 1)) +
    labs(title = "Where biomarker-trial investment is concentrated and growing — tumour types",
         subtitle = sprintf("x: industry-sponsored share; y: annual growth in biomarker-selected trial starts, %s\nVertical lines = 95%% CI of growth; hollow = small areas", yr_lab),
         x = "Industry-sponsored share", y = "Annual growth in trial starts",
         caption = SOURCE_CAPTION) +
    theme_landscape() + theme(legend.position = "right")

  # ---- 8. Investment map: biomarkers -----------------------------------------
  d8 <- tabs$by_biomarker |> filter(in_headline, !is.na(growth))
  plots$fig8_investment_biomarker <- ggplot(d8, aes(industry_share, growth)) +
    geom_hline(yintercept = ref, linetype = "dashed", colour = PAL$ink2, linewidth = 0.4) +
    geom_errorbar(aes(ymin = growth_lo, ymax = growth_hi), colour = PAL$industry,
                  width = 0, linewidth = 0.4, alpha = 0.5) +
    geom_point(aes(size = n_trials, shape = small_n), colour = PAL$industry, alpha = 0.8, stroke = 0.9) +
    scale_shape_manual(values = c(`FALSE` = 16, `TRUE` = 1),
                       labels = c(`FALSE` = sprintf("%d+ trials", SMALL_N),
                                  `TRUE` = sprintf("< %d trials", SMALL_N)), name = NULL) +
    ggrepel::geom_text_repel(aes(label = biomarker), size = 3, colour = PAL$ink,
                             min.segment.length = 0.2, seed = CFG$seed) +
    scale_size_area(max_size = 14, name = "Trials", labels = scales::label_comma()) +
    scale_x_continuous(labels = scales::label_percent(accuracy = 1)) +
    scale_y_continuous(labels = scales::label_percent(accuracy = 1)) +
    labs(title = "Where biomarker-trial investment is concentrated and growing — biomarkers",
         subtitle = sprintf("Dashed line: growth of all oncology trials, %s. Vertical lines = 95%% CI; hollow = small", yr_lab),
         x = "Industry-sponsored share", y = "Annual growth in trial starts",
         caption = SOURCE_CAPTION) +
    theme_landscape() + theme(legend.position = "right")

  # ---- 9. Top industry sponsors ---------------------------------------------
  d9 <- tabs$sponsors |> slice_max(n_bm_trials, n = 20, with_ties = FALSE) |>
    mutate(sponsor_clean = fct_reorder(sponsor_clean, n_bm_trials))
  plots$fig9_sponsors <- ggplot(d9, aes(n_bm_trials, sponsor_clean)) +
    geom_col(fill = PAL$industry, width = 0.72) +
    geom_text(aes(label = top_biomarker), hjust = -0.08, size = 2.9, colour = PAL$ink2) +
    scale_x_continuous(expand = expansion(c(0, 0.3))) +
    labs(title = "Industry sponsors running the most biomarker-selected trials",
         subtitle = "Label: the biomarker each sponsor selects for most often",
         x = "Biomarker-selected trials (lead sponsor)", y = NULL, caption = SOURCE_CAPTION) +
    theme_landscape()

  # ---- 10. Phase mix --------------------------------------------------------
  d10 <- tabs$phase_mix |> mutate(phase = fct_rev(phase))
  plots$fig10_phase_mix <- ggplot(d10, aes(share, selection, fill = phase)) +
    geom_col(width = 0.7, colour = "white", linewidth = 0.4) +
    facet_wrap(~ sponsor_type, ncol = 1) +
    scale_fill_manual(values = c("Phase 1" = PAL$seq[2], "Phase 2" = PAL$seq[4],
                                 "Phase 3" = PAL$seq[6], "Phase 4" = PAL$seq[7],
                                 "Not applicable / unknown" = "#d8d7d2"),
                      breaks = c("Phase 1", "Phase 2", "Phase 3", "Phase 4",
                                 "Not applicable / unknown"), name = NULL) +
    scale_x_continuous(labels = scales::label_percent()) +
    labs(title = "Phase mix: biomarker-selected vs other oncology trials",
         x = "Share of trials", y = NULL, caption = SOURCE_CAPTION) +
    theme_landscape()

  sizes <- list(fig3_tumour_types = c(9, 7), fig4_heatmap = c(11, 7.5),
                fig5_biomarker_trends = c(11, 7.5), fig6_tumour_share_trends = c(11, 7.5),
                fig7_investment_tumour = c(10, 7), fig8_investment_biomarker = c(10, 7),
                fig9_sponsors = c(9, 7), fig10_phase_mix = c(9, 4.5))
  for (nm in names(plots)) {
    s <- sizes[[nm]] %||% c(9, 5.5)
    save_fig(plots[[nm]], nm, width = s[1], height = s[2])
  }
  invisible(plots)
}
