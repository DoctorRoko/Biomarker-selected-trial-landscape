# =============================================================================
# 08_sensitivity.R — do the conclusions survive other reasonable definitions?
#
# Each scenario changes ONE choice and recomputes the headline numbers:
#   share selected overall / 2005-09 / 2021-25, growth, top tumours and
#   biomarkers, and the rank correlation of tumour shares with the baseline.
# If the story holds across scenarios, say so in the write-up; if not, report it.
# =============================================================================

MOLECULAR_GROUPS <- c("Oncogenic driver", "Haematologic driver",
                      "DNA repair / genomic instability", "Tumour suppressor")

SENSITIVITY_SCENARIOS <- list(
  "Baseline" =
    function(b) filter(b, status == "positive", !group %in% CFG$primary_exclude_groups),
  "Without ER/PR (hormone receptor)" =
    function(b) filter(b, status == "positive", !group %in% CFG$primary_exclude_groups,
                       biomarker != "ER/PR (hormone receptor)"),
  "Including lineage antigens (CD19, CD20, BCMA...)" =
    function(b) filter(b, status == "positive"),
  "Inclusion criteria only (title-only matches dropped)" =
    function(b) filter(b, status == "positive", in_inclusion,
                       !group %in% CFG$primary_exclude_groups),
  "Molecular biomarkers only (no PD-L1, hormone, antigen targets)" =
    function(b) filter(b, status == "positive", group %in% MOLECULAR_GROUPS),
  "Counting negative selection too (e.g. RAS wild-type)" =
    function(b) filter(b, status %in% c("positive", "negative"),
                       !group %in% CFG$primary_exclude_groups)
)

scenario_metrics <- function(name, selected_ids, trials, bm_rows, tumour_long) {
  t2 <- mutate(trials, sel = nct_id %in% selected_ids)
  early <- filter(t2, start_year <= 2009)
  late  <- filter(t2, start_year >= 2021)
  g     <- growth_by_key(filter(t2, sel) |> mutate(key = name), "g")

  tum <- tumour_long |>
    inner_join(select(t2, nct_id, sel), by = "nct_id") |>
    group_by(tumour) |>
    summarise(n_trials = n(), n_sel = sum(sel), pct = mean(sel), .groups = "drop") |>
    mutate(scenario = name)
  top_tu <- tum |> filter(!tumour %in% c("Other / unspecified", "Pan-tumour / multiple")) |>
    arrange(desc(n_sel)) |> head(3) |> pull(tumour)
  top_bm <- bm_rows |> filter(nct_id %in% trials$nct_id) |>
    distinct(nct_id, biomarker) |> count(biomarker, sort = TRUE) |> head(3) |> pull(biomarker)

  list(
    summary = tibble(
      scenario       = name,
      n_selected     = sum(t2$sel),
      pct_all        = mean(t2$sel),
      pct_2005_09    = mean(early$sel),
      pct_2021_25    = mean(late$sel),
      annual_growth  = g$g,
      growth_lo      = g$g_lo,
      growth_hi      = g$g_hi,
      top_tumours    = paste(top_tu, collapse = ", "),
      top_biomarkers = paste(top_bm, collapse = ", ")
    ),
    tumour = tum
  )
}

run_sensitivity <- function(trials, bm_trial, tumour_long) {
  res <- purrr::imap(SENSITIVITY_SCENARIOS, function(f, nm) {
    rows <- f(bm_trial)
    scenario_metrics(nm, unique(rows$nct_id), trials, rows, tumour_long)
  })

  # One more scenario: baseline biomarkers, but tumour types from free text only
  base_rows <- SENSITIVITY_SCENARIOS[["Baseline"]](bm_trial)
  tu_text   <- classify_tumours(trials, method = "text")
  res[["Tumour types from free text (not MeSH)"]] <-
    scenario_metrics("Tumour types from free text (not MeSH)", unique(base_rows$nct_id),
                     trials, base_rows, tu_text$tumour_long)

  summary <- purrr::map_dfr(res, "summary")
  tumour  <- purrr::map_dfr(res, "tumour")

  base <- tumour |> filter(scenario == "Baseline") |> select(tumour, base_pct = pct)
  rho  <- tumour |>
    inner_join(base, by = "tumour") |>
    group_by(scenario) |>
    summarise(tumour_rank_corr = suppressWarnings(cor(pct, base_pct, method = "spearman")),
              .groups = "drop")

  list(summary = left_join(summary, rho, by = "scenario"), tumour = tumour)
}

plot_sensitivity <- function(sens) {
  d <- sens$summary |>
    select(scenario, `2005–2009` = pct_2005_09, `2021–2025` = pct_2021_25) |>
    pivot_longer(-scenario, names_to = "period", values_to = "pct") |>
    mutate(scenario = factor(scenario, levels = rev(sens$summary$scenario)))
  p <- ggplot(d, aes(pct, scenario)) +
    geom_line(aes(group = scenario), colour = PAL$grid, linewidth = 1.4) +
    geom_point(aes(colour = period), size = 3) +
    scale_colour_manual(values = c(`2005–2009` = PAL$non_industry, `2021–2025` = PAL$industry),
                        name = NULL) +
    scale_x_continuous(labels = scales::label_percent(accuracy = 1), limits = c(0, NA)) +
    labs(title = "Sensitivity analysis: does the rise in biomarker selection hold?",
         subtitle = "Share of oncology treatment trials classed as biomarker-selected, early vs recent, under each definition",
         x = "Share biomarker-selected", y = NULL, caption = SOURCE_CAPTION) +
    theme_landscape()
  save_fig(p, "fig20_sensitivity", width = 10, height = 5.5)
  invisible(p)
}
