# =============================================================================
# 02_dictionaries.R — biomarker and tumour-type regular expressions
# Patterns use ICU regex. Gene symbols are case-SENSITIVE on purpose
# ("MET", "RET", "ALK" would otherwise match ordinary words); free-text names
# are wrapped in (?i: ... ) to make them case-insensitive.
# Edit these tables to change what is detected.
# =============================================================================

BIOMARKERS <- tibble::tribble(
  ~biomarker,            ~group,                              ~pattern,
  # ---- Oncogenic drivers (solid tumours) ----
  "EGFR",                "Oncogenic driver",                  "\\bEGFR(vIII)?\\b|(?i:epidermal growth factor receptor)(?![- ]?(2|II|type 2))",
  "HER2 (ERBB2)",        "Oncogenic driver",                  "\\bHER-?2(/neu)?\\b|\\bERBB-?2\\b|(?i:human epidermal growth factor receptor[- ]?2)",
  "ALK",                 "Oncogenic driver",                  "\\bALK\\b|(?i:anaplastic lymphoma kinase)",
  "ROS1",                "Oncogenic driver",                  "\\bROS-?1\\b",
  "BRAF",                "Oncogenic driver",                  "\\bBRAF\\b",
  "RAS (KRAS/NRAS)",     "Oncogenic driver",                  "\\b[KN]-?RAS\\b|\\bRAS\\b",
  "NTRK",                "Oncogenic driver",                  "\\bNTRK[1-3]?\\b|\\bTRK\\b",
  "RET",                 "Oncogenic driver",                  "\\bRET\\b",
  "MET",                 "Oncogenic driver",                  "\\b(c-)?MET\\b",
  "FGFR",                "Oncogenic driver",                  "\\bFGFR[1-4]?\\b",
  "PI3K/AKT/PTEN",       "Oncogenic driver",                  "\\bPIK3CA\\b|\\bAKT[1-3]?\\b|\\bPTEN\\b",
  "KIT/PDGFRA",          "Oncogenic driver",                  "\\b(c-)?KIT\\b|\\bPDGFRA\\b",
  "IDH1/2",              "Oncogenic driver",                  "\\bIDH-?(1/2|[12])?\\b",
  "ESR1",                "Oncogenic driver",                  "\\bESR1\\b",
  "Other rare drivers",  "Oncogenic driver",                  "\\bNRG-?1\\b|\\bHRAS\\b|\\bMAP2K1\\b|\\bERBB3\\b|\\bNF1\\b",
  # ---- Haematological drivers ----
  "FLT3",                "Haematologic driver",               "\\bFLT-?3\\b",
  "NPM1",                "Haematologic driver",               "\\bNPM-?1\\b",
  "BCR::ABL1 / Ph+",     "Haematologic driver",               "\\bBCR[-:/ ]{0,2}ABL1?\\b|(?i:philadelphia chromosome)|\\bPh\\+|\\bPh-(positive|negative)",
  "KMT2A / NUP98",       "Haematologic driver",               "\\bKMT2A\\b|\\bMLL-?r\\b|\\bMLL[- ]rearrang|\\bNUP98\\b",
  # ---- DNA repair / genomic instability ----
  "BRCA / HRR / HRD",    "DNA repair / genomic instability",  "\\bg?BRCA(1/2|[12])?\\b|\\bHRD\\b|\\bHRR\\b|\\bPALB2\\b|\\bATM\\b|(?i:homologous recombination)",
  "MSI-H / dMMR",        "DNA repair / genomic instability",  "\\bMSI(-?H)?\\b|\\b[dp]MMR\\b|\\bMSS\\b|(?i:microsatellite)|(?i:mismatch[- ]repair)",
  "TMB",                 "DNA repair / genomic instability",  "\\bTMB(-?H)?\\b|(?i:tumou?r mutation(al)? burden)",
  "TP53",                "Tumour suppressor",                 "\\bTP53\\b|\\bp53\\b",
  # ---- Immunotherapy ----
  "PD-L1",               "Immunotherapy biomarker",           "\\bPD-?L1\\b|\\bB7-?H1\\b",
  "HLA type (TCR therapy)", "Immunotherapy biomarker",        "\\bHLA-?A\\s?\\*?\\s?0?2\\b|\\bHLA-A2\\b",
  # ---- Hormone receptors ----
  "ER/PR (hormone receptor)", "Hormone receptor",             "\\bER\\b|\\bPgR\\b|\\bPR[+-]|\\bHR[+-]|\\bHR[- ](positive|negative)|(?i:(o)?estrogen receptor|progesterone receptor|hormone[- ]receptor)",
  "Androgen receptor",   "Hormone receptor",                  "\\bAR\\b|\\bAR-?V7\\b|(?i:androgen receptor)",
  # ---- Antigen targets used to select patients (ADC, radioligand, etc.) ----
  "PSMA",                "Antigen target",                    "\\bPSMA\\b",
  "Claudin 18.2",        "Antigen target",                    "\\bCLDN-?18(\\.2)?\\b|(?i:claudin[- ]?18)",
  "Other ADC targets",   "Antigen target",                    "\\bDLL-?3\\b|(?i:nectin-?4)|\\bTROP-?2\\b|\\bFR(a|\u03b1|alpha)\\b|(?i:folate receptor)|\\bB7-?H3\\b|\\bCEACAM5\\b|\\bSSTR2?\\b",
  # ---- Haematological lineage antigens (recorded, excluded from headline) ----
  "CD19/CD20/CD22/CD30/CD33/CD38/BCMA", "Haematologic lineage antigen",
                                                              "\\bCD(19|20|22|30|33|38|123)\\b|\\bBCMA\\b"
)

# Words near a biomarker mention that indicate patients are selected FOR it.
POS_CTX <- paste0(
  "(?i)(positiv|\\+|mutat|mutant|alteration|altered|aberration|amplif|over-?express|",
  "rearrang|fusion|translocat|deletion|insertion|skipping|\\bexon\\b|harbou?r|",
  "\\bcarr(y|ies|ying|ier)|pathogenic|\\bvariant|deficien|instabil|\\bhigh\\b|\\blow\\b|",
  "\u2265|>=|>|\\btps\\b|\\bcps\\b|\\bscore\\b|express|detected|driven|",
  "v600|g12[cdvr]|l858r|t790m|\\bitd\\b|activating|sensiti[sz]ing|msi-?h\\b|\\bdmmr\\b)"
)

# Words that indicate selection AGAINST it (wild-type, negative, stable...).
# A mention matching both is classed as negative (e.g. "EGFR mutation-negative").
NEG_CTX <- paste0(
  "(?i)(negativ|wild[- ]?type|\\bwt\\b|non-?mutat|un-?mutated|without|absence|absent|",
  "\\bno (known|documented|evidence)|\\bnot (have|harbou?r|carry)|\\black|proficien|",
  "\\bpmmr\\b|\\bmss\\b|microsatellite[- ]stable|<|\u2264|",
  "(?<=[A-Za-z0-9])[-\u2212](?=\\s|$))"
)

# Context windows are cut at these delimiters so that "HR-positive, HER2-negative"
# gives HR -> positive and HER2 -> negative.
PRE_DELIM  <- "^.*([,;:|/(]|\\.\\s| and | or | but )"
POST_DELIM <- "([,;:|/)]|\\.\\s| and | or | but ).*$"

# Inclusion lines that are really exclusions ("patients with known EGFR mutation
# are not eligible") — every mention on such a line is treated as negative.
EXCL_LINE <- "(?i)(not (be )?eligible|ineligible|are excluded|will be excluded|is excluded|exclusion)"

# ---- Tumour types -------------------------------------------------------------
# Matched against conditions + keywords + brief title. Order = priority when a
# single "primary" tumour is needed.
TUMOURS <- tibble::tribble(
  ~tumour,                    ~category,        ~pattern,
  "Breast",                   "Solid",          "(?i:breast)",
  "Lung",                     "Solid",          "(?i:lung|bronch|mesotheli)|\\bN?SCLC\\b",
  "Colorectal",               "Solid",          "(?i:colorectal|\\bcolon\\b|rectal|rectum|bowel cancer)|\\bm?CRC\\b",
  "Gastro-oesophageal",       "Solid",          "(?i:gastric|stomach|o?esophag|gastro-?o?esophageal)|\\bGE?JC?\\b",
  "Pancreatic",               "Solid",          "(?i:pancrea)",
  "Hepatobiliary",            "Solid",          "(?i:hepatocellular|liver (cancer|carcinoma|neoplasm|metast)|biliary|cholangio|gallbladder)|\\bHCC\\b|\\bBTC\\b",
  "Prostate",                 "Solid",          "(?i:prostat)|\\bm?CRPC\\b",
  "Urothelial / bladder",     "Solid",          "(?i:bladder|urothelial|ureter|transitional cell)",
  "Kidney",                   "Solid",          "(?i:renal cell|kidney (cancer|carcinoma|neoplasm)|renal (cancer|carcinoma|neoplasm))|\\bRCC\\b",
  "Ovarian",                  "Solid",          "(?i:ovar|fallopian|primary peritoneal)",
  "Endometrial / uterine",    "Solid",          "(?i:endometri(al|um) (cancer|carcinoma|neoplasm)|uterine|uterus|endometrial)",
  "Cervical",                 "Solid",          "(?i:cervical (cancer|carcinoma|neoplasm|intraepithelial)|cervix|uterine cervical)",
  "Head and neck",            "Solid",          "(?i:head and neck|oropharyn|nasopharyn|laryn|hypopharyn|oral cavity|oral cancer|salivary|tongue)|\\bS?CCHN\\b|\\bHNSCC\\b",
  "Thyroid",                  "Solid",          "(?i:thyroid)",
  "Melanoma / skin",          "Solid",          "(?i:melanoma|merkel|basal cell carcinoma|cutaneous squamous|skin (cancer|neoplasm))",
  "CNS / glioma",             "Solid",          "(?i:glioma|glioblastoma|astrocytoma|oligodendro|brain (tumou?r|neoplasm|cancer)|medulloblastoma|ependymoma)|\\bDIPG\\b|\\bGBM\\b",
  "Sarcoma / GIST",           "Solid",          "(?i:sarcoma|gastrointestinal stromal|ewing|desmoid|chordoma)|\\bGIST\\b",
  "Neuroendocrine",           "Solid",          "(?i:neuroendocrine|carcinoid|pheochromocytoma|paraganglioma)",
  "Acute myeloid leukaemia",  "Haematological", "(?i:acute myelo(id|genous|blastic|cytic))|\\bAML\\b",
  "Acute lymphoblastic leukaemia", "Haematological", "(?i:acute lympho(blastic|cytic))|\\b[BT]-?ALL\\b|\\bALL\\b",
  "CLL / CML",                "Haematological", "(?i:chronic lymphocytic|chronic myelo(id|genous)|small lymphocytic)|\\bCLL\\b|\\bCML\\b",
  "MDS / MPN",                "Haematological", "(?i:myelodysplas|myeloproliferative|myelofibrosis|polycyth|thrombocythemia|mastocytosis)|\\bMDS\\b|\\bMPN\\b",
  "Lymphoma",                 "Haematological", "(?i:lymphoma|hodgkin|waldenstr|mycosis fungoides)|\\bDLBCL\\b",
  "Multiple myeloma",         "Haematological", "(?i:myeloma|plasma cell)"
)

PAN_TUMOUR_PATTERN <- paste0(
  "(?i:solid tumou?r|advanced (cancer|malignan)|metastatic cancer|tumou?r[- ]agnostic|",
  "pan-tumou?r|histology[- ]agnostic|basket|any tumou?r type|neoplasms?$)"
)

# ---- Tumour types from MeSH terms (enhanced version) -------------------------
# ClinicalTrials.gov maps each trial's conditions to standard MeSH terms
# (derivedSection). Matching those is more consistent than free text. Only the
# trial's own MeSH terms are used, not ancestors: broad ancestors such as
# "Uterine Neoplasms" would wrongly pull cervical trials into endometrial.
MESH_TUMOURS <- tibble::tribble(
  ~tumour,                         ~pattern,
  "Breast",                        "Breast Neoplasms|Triple Negative Breast",
  "Lung",                          "Lung Neoplasms|Carcinoma, Non-Small-Cell Lung|Small Cell Lung Carcinoma|Mesothelioma",
  "Colorectal",                    "Colorectal Neoplasms|Colonic Neoplasms|Rectal Neoplasms",
  "Gastro-oesophageal",            "Stomach Neoplasms|Esophageal Neoplasms|Esophageal Squamous Cell Carcinoma",
  "Pancreatic",                    "Pancreatic Neoplasms|Carcinoma, Pancreatic Ductal",
  "Hepatobiliary",                 "Liver Neoplasms|Carcinoma, Hepatocellular|Biliary Tract Neoplasms|Cholangiocarcinoma|Bile Duct Neoplasms|Gallbladder Neoplasms|Klatskin",
  "Prostate",                      "Prostatic Neoplasms",
  "Urothelial / bladder",          "Urinary Bladder Neoplasms|Carcinoma, Transitional Cell|Ureteral Neoplasms",
  "Kidney",                        "Kidney Neoplasms|Carcinoma, Renal Cell",
  "Ovarian",                       "Ovarian Neoplasms|Fallopian Tube Neoplasms|Peritoneal Neoplasms|Carcinoma, Ovarian Epithelial",
  "Endometrial / uterine",         "Endometrial Neoplasms|Uterine Neoplasms(?!.*Cervical)|Carcinosarcoma",
  "Cervical",                      "Uterine Cervical Neoplasms",
  "Head and neck",                 "Squamous Cell Carcinoma of Head and Neck|Head and Neck Neoplasms|Nasopharyngeal|Oropharyngeal|Laryngeal|Hypopharyngeal|Mouth Neoplasms|Tongue Neoplasms|Salivary Gland",
  "Thyroid",                       "Thyroid Neoplasms|Thyroid Carcinoma",
  "Melanoma / skin",               "Melanoma|Skin Neoplasms|Carcinoma, Merkel Cell|Carcinoma, Basal Cell",
  "CNS / glioma",                  "Glioma|Glioblastoma|Brain Neoplasms|Astrocytoma|Medulloblastoma|Ependymoma|Oligodendroglioma|Central Nervous System Neoplasms",
  "Sarcoma / GIST",                "Sarcoma|Gastrointestinal Stromal Tumors|Osteosarcoma|Fibromatosis, Aggressive",
  "Neuroendocrine",                "Neuroendocrine Tumors|Carcinoid Tumor|Carcinoma, Neuroendocrine|Pheochromocytoma|Paraganglioma",
  "Acute myeloid leukaemia",       "Leukemia, Myeloid, Acute|Leukemia, Myelomonocytic, Acute|Leukemia, Promyelocytic, Acute",
  "Acute lymphoblastic leukaemia", "Lymphoblastic",
  "CLL / CML",                     "Leukemia, Lymphocytic, Chronic|Leukemia, Myelogenous, Chronic|Leukemia, Myeloid, Chronic",
  "MDS / MPN",                     "Myelodysplastic Syndromes|Myeloproliferative Disorders|Primary Myelofibrosis|Polycythemia Vera|Thrombocythemia, Essential|Mastocytosis",
  "Lymphoma",                      "(?<!Leukemia-)Lymphoma|Hodgkin Disease|Waldenstrom|Mycosis Fungoides",
  "Multiple myeloma",              "Multiple Myeloma|Plasmacytoma"
)
stopifnot(setequal(MESH_TUMOURS$tumour, TUMOURS$tumour))

# ---- Trial designs and liquid biopsy (enhanced version) ----------------------
DESIGN_PATTERNS <- tibble::tribble(
  ~design,      ~pattern,
  "Basket",     "(?i:basket|tumou?r[- ]agnostic|histology[- ]agnostic|tissue[- ]agnostic|site[- ]agnostic)",
  "Umbrella",   "(?i:umbrella)",
  "Platform",   "(?i:platform (trial|study|protocol)|master protocol|adaptive platform)"
)

# Biomarker detected in blood rather than tissue
LIQUID_BIOPSY_PATTERN <- paste0(
  "(?i:ctDNA|circulating tumou?r DNA|cell-free DNA|cfDNA|liquid biopsy|plasma[- ]based|",
  "plasma (genotyp|NGS|sequenc|test|assay|sample)|blood[- ]based (assay|test|NGS)|",
  "guardant|foundationone ?liquid)"
)

# Why trials stopped (applied to the free-text whyStopped field, in this order)
STOP_REASONS <- tibble::tribble(
  ~reason,                       ~pattern,
  "Accrual / enrolment",         "(?i:accru|enrol|enroll|recruit|slow|insufficient (patient|subject|participant)|low (patient|participation))",
  "Efficacy / futility",         "(?i:futil|efficac|lack of (benefit|response|activity)|interim analysis|did not meet|ineffective|no (benefit|response))",
  "Safety / toxicity",           "(?i:safety|toxicit|adverse|death|side effect)",
  "Business / strategic",        "(?i:business|strateg|sponsor decision|portfolio|commercial|company decision|priorit|financ|funding|budget|acquisition|merger)",
  "Drug supply / logistics",     "(?i:drug (supply|availab)|supply|manufactur|logistic|availability)",
  "PI / site / administrative",  "(?i:\\bPI\\b|principal investigator|investigator (left|leav|moved)|site|administrat|IRB|regulator|staff|COVID|pandemic)"
)
