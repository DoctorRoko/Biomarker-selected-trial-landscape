# =============================================================================
# Re-draw all figures and re-render the report WITHOUT re-running the analysis.
# Needs data/landscape_results.rds from a previous source("run_all.R").
# Use this when you tweak figure code (R/05_plots.R, R/12_figures.R, ...).
# =============================================================================

for (f in c("00_config.R", "02_dictionaries.R", "03_classify.R", "04_analyse.R", "05_plots.R",
            "07_extensions.R", "08_sensitivity.R", "09_outcomes.R", "12_figures.R")) {
  source(file.path("R", f))
}
res <- readRDS(file.path(CFG$data_dir, "landscape_results.rds"))

clear_figures()
make_main_figures(res$tabs, res$ext, res$sens)
plot_outcomes(res$outc)
plot_sensitivity(res$sens)
make_plots(res$tabs)
make_extension_plots(res$ext, res$tabs)
# The ChiCTR figure (S11) is only drawn by run_all.R when an ICTRP export exists.

if (requireNamespace("rmarkdown", quietly = TRUE) && rmarkdown::pandoc_available()) {
  rmarkdown::render("report.Rmd", output_dir = CFG$out_dir, quiet = TRUE)
  rmarkdown::render("manuscript.Rmd", output_dir = CFG$out_dir, quiet = TRUE)
  message("Report and manuscript re-rendered in ", CFG$out_dir)
}
