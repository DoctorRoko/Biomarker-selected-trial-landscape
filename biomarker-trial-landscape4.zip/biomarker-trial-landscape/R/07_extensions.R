# =============================================================================
# 07_extensions.R — four extensions to the core landscape
#
#   A. Drug type (modality): ADC, radioligand, cell therapy, bispecific,
#      checkpoint inhibitor, targeted small molecule, ... from intervention names
#   B. Geography: where trials run (United States, China, Europe, Japan, ...)
#   C. Company portfolios: which sponsors bet on which biomarkers / modalities
#   D. FDA approvals: do trial starts rise before biomarker-defined approvals?
#      (uses the curated table reference/fda_biomarker_approvals.csv)
# =============================================================================

# ---- A. Modality dictionary --------------------------------------------------
# Each intervention is assigned the FIRST matching modality (order = priority),
# so "trastuzumab deruxtecan" is an ADC, not a plain antibody.
MODALITIES <- tibble::tribble(
  ~modality,                    ~pattern,
  "Placebo / control",          "placebo|\\bsham\\b|best supportive care|observation only",
  "Antibody-drug conjugate",    paste0("vedotin|deruxtecan|emtansine|govitecan|tesirine|ozogamicin|mafodotin|",
                                       "soravtansine|duocarmazine|ravtansine|rezetecan|\\bADC\\b|antibody[- ]drug conjugate|",
                                       "disitamab|\\bRC48\\b|\\bSKB-?264\\b|sacituzumab|datopotamab|patritumab|",
                                       "telisotuzumab|ifinatamab|mirvetuximab|tisotumab|enfortumab|loncastuximab|",
                                       "polatuzumab|brentuximab|belantamab|inotuzumab|gemtuzumab|\\bSHR-A\\d{4}\\b"),
  "Radioligand / radionuclide", paste0("177\\s?Lu|Lu-?177|lutetium|225\\s?Ac|Ac-?225|actinium|radioligand|",
                                       "radionuclide|PSMA-617|PSMA I&T|dotatate|dotatoc|radium[- ]?223|",
                                       "\\bI-?131\\b|iodine[- ]131|yttrium|\\bY-?90\\b|pluvicto|lutathera|xofigo"),
  "Cell therapy",               paste0("\\bCAR[- ]?T\\b|\\bCAR\\b|chimeric antigen receptor|\\bTCR[- ]?T\\b|",
                                       "T[- ]cell receptor|tumou?r[- ]infiltrating lymphocyte|\\bTILs?\\b|",
                                       "(leucel|lecleucel|temcel|cabtagene)\\b|\\bNK[- ]cells?\\b|\\bCIK\\b"),
  "Bispecific / T-cell engager", paste0("bispecific|\\bBiTE\\b|blinatumomab|teclistamab|talquetamab|elranatamab|",
                                       "epcoritamab|glofitamab|mosunetuzumab|tarlatamab|tebentafusp|amivantamab|",
                                       "zanidatamab|ivonescimab|cadonilimab|zenocutuzumab|linvoseltamab|odronextamab"),
  "Checkpoint inhibitor",       paste0("pembrolizumab|nivolumab|atezolizumab|durvalumab|avelumab|cemiplimab|",
                                       "dostarlimab|ipilimumab|tremelimumab|tislelizumab|toripalimab|sintilimab|",
                                       "camrelizumab|serplulimab|penpulimab|retifanlimab|relatlimab|sugemalimab|",
                                       "envafolimab|adebrelimab|benmelstobart|anti-?PD-?L?1|anti-?CTLA-?4|",
                                       "PD-1 (inhibitor|antibody|blockade)|checkpoint inhibitor"),
  "Monoclonal antibody (other)", paste0("trastuzumab|pertuzumab|cetuximab|panitumumab|bevacizumab|ramucirumab|",
                                       "zolbetuximab|necitumumab|margetuximab|rituximab|obinutuzumab|daratumumab|",
                                       "isatuximab|elotuzumab|dinutuximab|olaratumab|mogamulizumab|\\b[a-z]+mab\\b"),
  "Targeted small molecule",    paste0("\\b[a-z]+(tinib|rafenib|metinib|parib|ciclib|lisib|rasib|denib|sertib|",
                                       "zomib|degib|toclax|tasertib|lisertib|stat)\\b|sotorasib|adagrasib|",
                                       "alpelisib|capivasertib|inavolisib|ivosidenib|enasidenib|olutasidenib|",
                                       "vorasidenib|revumenib|ziftomenib|midostaurin|tazemetostat|everolimus|",
                                       "temsirolimus|lenalidomide|pomalidomide|thalidomide"),
  "Endocrine therapy",          paste0("letrozole|anastrozole|exemestane|tamoxifen|fulvestrant|elacestrant|",
                                       "camizestrant|imlunestrant|giredestrant|vepdegestrant|enzalutamide|",
                                       "abiraterone|apalutamide|darolutamide|bicalutamide|goserelin|leuprolide|",
                                       "leuprorelin|degarelix|relugolix|triptorelin|megestrol|aromatase inhibitor|",
                                       "endocrine therapy|hormon(e|al) therapy|androgen deprivation"),
  "Chemotherapy",               paste0("platin|taxel|rubicin|fluorouracil|\\b5-?FU\\b|capecitabine|gemcitabine|",
                                       "pemetrexed|cyclophosphamide|irinotecan|topotecan|etoposide|cytarabine|",
                                       "azacitidine|decitabine|vincristine|vinorelbine|eribulin|ifosfamide|",
                                       "temozolomide|methotrexate|fludarabine|bendamustine|melphalan|busulfan|",
                                       "trabectedin|\\bS-1\\b|tegafur|mitomycin|bleomycin|dacarbazine|",
                                       "chemotherapy|FOLFOX|FOLFIRI|FOLFIRINOX|CAPOX|XELOX"),
  "Vaccine / oncolytic virus",  "vaccine|\\bmRNA-\\d|neoantigen|oncolytic|talimogene"
)

NOVEL_MODALITIES <- c("Antibody-drug conjugate", "Radioligand / radionuclide",
                      "Cell therapy", "Bispecific / T-cell engager")

# ---- B. Regions ---------------------------------------------------------------
EUROPE_COUNTRIES <- c(
  "Austria", "Belgium", "Bulgaria", "Croatia", "Cyprus", "Czechia", "Czech Republic",
  "Denmark", "Estonia", "Finland", "France", "Germany", "Greece", "Hungary", "Ireland",
  "Italy", "Latvia", "Lithuania", "Luxembourg", "Malta", "Netherlands", "Poland",
  "Portugal", "Romania", "Slovakia", "Slovenia", "Spain", "Sweden", "Iceland",
  "Liechtenstein", "Norway", "United Kingdom", "Switzerland"
)
OTHER_APAC_COUNTRIES <- c(
  "Korea, Republic of", "South Korea", "Taiwan", "Hong Kong", "Australia", "New Zealand",
  "Singapore", "India", "Thailand", "Malaysia", "Vietnam", "Philippines", "Indonesia"
)
REGION_LEVELS <- c("United States", "China", "Europe", "Japan", "Other Asia-Pacific",
                   "Rest of world")
REGION_COLOURS <- setNames(c("#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300"),
                           REGION_LEVELS)

country_to_region <- function(cty) {
  case_when(
    cty == "United States"         ~ "United States",
    cty == "China"                 ~ "China",
    cty == "Japan"                 ~ "Japan",
    cty %in% EUROPE_COUNTRIES      ~ "Europe",
    cty %in% OTHER_APAC_COUNTRIES  ~ "Other Asia-Pacific",
    TRUE                           ~ "Rest of world"
  )
}

# ---- C. Sponsor parent companies ------------------------------------------------
# Subsidiaries and acquisitions are mapped to the CURRENT parent (as of 2025),
# so e.g. Seagen trials count under Pfizer and Mirati under BMS. Edit as needed.
SPONSOR_ALIASES <- tibble::tribble(
  ~parent,                ~pattern,
  "Roche",                "roche|genentech|chugai",
  "AstraZeneca",          "astrazeneca|medimmune|alexion",
  "Merck & Co. (MSD)",    "merck sharp|\\bmsd\\b|merck & co",
  "Merck KGaA",           "merck kgaa|emd serono",
  "Bristol Myers Squibb", "bristol|celgene|mirati|turning point|juno",
  "Pfizer",               "pfizer|seagen|seattle genetics|array biopharma|wyeth|medivation",
  "Novartis",             "novartis|advanced accelerator|endocyte",
  "Eli Lilly",            "lilly|loxo",
  "Johnson & Johnson",    "janssen|johnson",
  "Daiichi Sankyo",       "daiichi",
  "Amgen",                "amgen",
  "Bayer",                "bayer",
  "Takeda",               "takeda|millennium|ariad",
  "AbbVie",               "abbvie|pharmacyclics|immunogen",
  "Gilead",               "gilead|immunomedics|kite",
  "GSK",                  "glaxo|\\bgsk\\b|tesaro",
  "Sanofi",               "sanofi",
  "Astellas",             "astellas",
  "Eisai",                "eisai",
  "Boehringer Ingelheim", "boehringer",
  "Jiangsu Hengrui",      "hengrui",
  "BeiGene / BeOne",      "beigene|beone",
  "Innovent",             "innovent",
  "Akeso",                "akeso",
  "Hansoh",               "hansoh",
  "Sichuan Kelun",        "kelun",
  "CSPC",                 "\\bcspc\\b",
  "Hutchmed",             "hutchmed|hutchison",
  "Zai Lab",              "zai lab"
)

canonical_sponsor <- function(x) {
  out <- rep(NA_character_, length(x))
  for (i in seq_len(nrow(SPONSOR_ALIASES))) {
    hit <- is.na(out) & str_detect(coalesce(x, ""), regex(SPONSOR_ALIASES$pattern[i], ignore_case = TRUE))
    out[hit] <- SPONSOR_ALIASES$parent[i]
  }
  coalesce(out, clean_sponsor(x))
}

# ---- A. Classify modalities -------------------------------------------------------
classify_modalities <- function(trials) {
  # Enhanced version: by default classify only what is given in EXPERIMENTAL
  # arms, so a chemotherapy control arm doesn't make a trial "test chemotherapy".
  use_exp <- CFG$modality_arms == "experimental" && "interventions_experimental" %in% names(trials)
  src  <- if (use_exp) coalesce(trials$interventions_experimental, trials$interventions) else trials$interventions
  from <- if (use_exp) if_else(is.na(trials$interventions_experimental), "all interventions",
                               "experimental arms") else "all interventions"

  iv <- tibble(nct_id = trials$nct_id, item = src, source = from) |>
    filter(!is.na(item)) |>
    separate_rows(item, sep = "; ") |>
    mutate(type = toupper(str_extract(item, "^[A-Za-z_ ]+(?=: )")),   # "Drug: X" and "DRUG: X"
           name = str_remove(item, "^[A-Za-z_ ]+: "),
           modality = NA_character_)

  for (i in seq_len(nrow(MODALITIES))) {
    hit <- is.na(iv$modality) &
      str_detect(iv$name, regex(MODALITIES$pattern[i], ignore_case = TRUE))
    iv$modality[hit] <- MODALITIES$modality[i]
  }
  iv <- iv |>
    mutate(modality = case_when(
      !is.na(modality)                  ~ modality,
      type == "RADIATION"               ~ "Radiotherapy",
      type %in% c("PROCEDURE", "DEVICE") ~ "Procedure / device",
      TRUE                              ~ "Other / unclassified"
    ))

  modality_long <- iv |>
    filter(modality != "Placebo / control") |>
    distinct(nct_id, modality)

  flags <- modality_long |>
    group_by(nct_id) |>
    summarise(modalities     = paste(sort(unique(modality)), collapse = "; "),
              novel_modality = any(modality %in% NOVEL_MODALITIES),
              .groups = "drop")

  list(
    trials = trials |>
      left_join(flags, by = "nct_id") |>
      mutate(novel_modality = coalesce(novel_modality, FALSE)),
    modality_long = modality_long,
    interventions = iv
  )
}

# ---- B. Classify geography ----------------------------------------------------------
classify_geography <- function(trials) {
  region_long <- tibble(nct_id = trials$nct_id, country = trials$countries) |>
    filter(!is.na(country)) |>
    separate_rows(country, sep = "; ") |>
    mutate(region = country_to_region(country)) |>
    distinct(nct_id, region)

  profile <- region_long |>
    group_by(nct_id) |>
    summarise(n_regions = n_distinct(region),
              regions   = paste(sort(unique(region)), collapse = "; "),
              region_profile = if (n_regions == 1) paste(first(region), "only") else "Multi-region",
              .groups = "drop")

  list(
    trials = trials |>
      left_join(profile, by = "nct_id") |>
      mutate(region_profile = coalesce(region_profile, "No sites listed"),
             n_regions      = coalesce(n_regions, 0L)),
    region_long = region_long
  )
}

# ---- D. FDA approvals -----------------------------------------------------------------
load_approvals <- function(path = file.path("reference", "fda_biomarker_approvals.csv")) {
  appr <- readr::read_csv(path, show_col_types = FALSE, comment = "#")
  unknown <- setdiff(unique(appr$biomarker), BIOMARKERS$biomarker)
  if (length(unknown)) warning("Approval biomarkers not in BIOMARKERS: ", paste(unknown, collapse = ", "))
  appr
}

# ---- Analysis ---------------------------------------------------------------------------
analyse_extensions <- function(trials, bm_trial, modality_long, region_long, approvals) {
  recent    <- CFG$recent_years[1]:CFG$recent_years[2]
  all_years <- min(trials$start_year):max(trials$start_year)

  bm_pos <- bm_trial |>
    filter(status == "positive", !group %in% CFG$primary_exclude_groups,
           nct_id %in% trials$nct_id) |>
    left_join(select(trials, nct_id, start_year, sponsor, sponsor_type), by = "nct_id")
  sel <- filter(trials, biomarker_selected)

  # ---- A. Modalities ----
  ml <- modality_long |>
    inner_join(select(trials, nct_id, start_year, biomarker_selected, sponsor_type),
               by = "nct_id")

  modality_summary <- ml |>
    group_by(modality) |>
    summarise(
      n_trials          = n(),
      n_bm              = sum(biomarker_selected),
      pct_bm            = n_bm / n_trials,
      bm_industry_share = mean(sponsor_type[biomarker_selected] == "Industry"),
      n_bm_recent       = sum(biomarker_selected & start_year %in% recent),
      .groups = "drop"
    ) |>
    left_join(growth_by_key(filter(ml, biomarker_selected) |> rename(key = modality), "bm_growth"),
              by = c("modality" = "key")) |>
    arrange(desc(n_bm))

  modality_year <- ml |>
    filter(biomarker_selected) |>
    count(modality, start_year, name = "n_bm") |>
    left_join(count(sel, start_year, name = "all_bm"), by = "start_year") |>
    mutate(share_of_bm = n_bm / all_bm)

  modality_biomarker <- bm_pos |>
    select(nct_id, biomarker) |>
    inner_join(modality_long, by = "nct_id", relationship = "many-to-many") |>
    count(modality, biomarker, name = "n_trials")

  # ---- B. Geography ----
  rl <- region_long |>
    inner_join(select(trials, nct_id, start_year, biomarker_selected), by = "nct_id")

  region_year <- rl |>
    group_by(region, start_year) |>
    summarise(n_trials = n(), n_bm = sum(biomarker_selected), .groups = "drop") |>
    left_join(trials |> filter(n_regions > 0) |>
                group_by(start_year) |>
                summarise(all_trials = n(), all_bm = sum(biomarker_selected), .groups = "drop"),
              by = "start_year") |>
    mutate(share_of_bm_trials = n_bm / all_bm,       # % of biomarker trials with a site here
           pct_bm_in_region   = n_bm / n_trials)      # % of this region's trials that are biomarker-selected

  region_profile_year <- sel |>
    count(start_year, region_profile) |>
    group_by(start_year) |>
    mutate(share = n / sum(n)) |>
    ungroup()

  region_biomarker <- bm_pos |>
    filter(start_year %in% recent) |>
    select(nct_id, biomarker) |>
    left_join(region_long, by = "nct_id", relationship = "many-to-many") |>
    group_by(biomarker) |>
    mutate(n_recent = n_distinct(nct_id),
           n_with_sites = n_distinct(nct_id[!is.na(region)])) |>
    filter(!is.na(region)) |>
    group_by(biomarker, n_recent, n_with_sites, region) |>
    summarise(n = n_distinct(nct_id), .groups = "drop") |>
    mutate(share = n / n_with_sites)

  china_only_biomarker <- bm_pos |>
    filter(start_year %in% recent) |>
    left_join(select(trials, nct_id, region_profile), by = "nct_id") |>
    group_by(biomarker) |>
    summarise(n_recent = n(), china_only = mean(region_profile == "China only"),
              us_only = mean(region_profile == "United States only"),
              multi_region = mean(region_profile == "Multi-region"), .groups = "drop") |>
    arrange(desc(china_only))

  # ---- C. Company portfolios ----
  ind <- bm_pos |>
    filter(sponsor_type == "Industry") |>
    mutate(parent = canonical_sponsor(sponsor))

  portfolio_biomarker <- ind |>
    count(parent, biomarker, name = "n_trials") |>
    group_by(parent) |>
    mutate(share_of_portfolio = n_trials / sum(n_trials)) |>
    ungroup()

  portfolio_modality <- ind |>
    distinct(nct_id, parent) |>
    inner_join(modality_long, by = "nct_id", relationship = "many-to-many") |>
    count(parent, modality, name = "n_trials") |>
    group_by(parent) |>
    mutate(share_of_portfolio = n_trials / sum(n_trials)) |>
    ungroup()

  portfolio_summary <- ind |>
    group_by(parent) |>
    summarise(
      n_bm_trials     = n_distinct(nct_id),
      n_recent        = n_distinct(nct_id[start_year %in% recent]),
      n_biomarkers    = n_distinct(biomarker),
      top_biomarker   = names(which.max(table(biomarker))),
      top_share       = max(table(biomarker)) / n(),
      # Herfindahl index: 1 = all trials on one biomarker, ~0 = spread across many
      concentration   = sum((table(biomarker) / n())^2),
      .groups = "drop"
    ) |>
    mutate(recent_share = n_recent / n_bm_trials) |>
    arrange(desc(n_bm_trials))

  # ---- D. Approvals vs trials ----
  appr_window <- approvals |> filter(approval_year %in% all_years)

  first_approval <- approvals |>
    group_by(biomarker) |>
    summarise(first_approval = min(approval_year), n_approvals = n(),
              n_approvals_window = sum(approval_year %in% all_years), .groups = "drop")

  panel <- bm_pos |>
    count(biomarker, start_year, name = "trials") |>
    complete(biomarker, start_year = all_years, fill = list(trials = 0L)) |>
    left_join(count(appr_window, biomarker, approval_year, name = "approvals"),
              by = c("biomarker", "start_year" = "approval_year")) |>
    mutate(approvals = coalesce(approvals, 0L)) |>
    rename(year = start_year)

  # Event study: trial starts in the years around a biomarker's FIRST approval,
  # indexed to each biomarker's own average (so big and small biomarkers weigh equally).
  es_window <- -5:4
  bm_year_total <- count(sel, start_year, name = "total") |> rename(year = start_year)
  event_study <- panel |>
    inner_join(first_approval, by = "biomarker") |>
    filter(first_approval + min(es_window) >= min(all_years),
           first_approval + max(es_window) <= max(all_years)) |>
    mutate(rel_year = year - first_approval) |>
    filter(rel_year %in% es_window) |>
    # Detrend: use the biomarker's SHARE of all biomarker-selected trials that year,
    # otherwise the field's overall ~10%/yr growth makes every window slope upward.
    left_join(bm_year_total, by = "year") |>
    mutate(share = trials / total) |>
    group_by(biomarker) |>
    mutate(index = share / mean(share)) |>
    filter(is.finite(index)) |>
    group_by(rel_year) |>
    summarise(mean_index = mean(index), se = sd(index) / sqrt(n()),
              n_biomarkers = n(), .groups = "drop")

  event_biomarkers <- panel |>
    inner_join(first_approval, by = "biomarker") |>
    filter(first_approval + min(es_window) >= min(all_years),
           first_approval + max(es_window) <= max(all_years)) |>
    distinct(biomarker, first_approval)

  # Lead-lag: do trial starts k years earlier predict approvals this year?
  lag_models <- map_dfr(0:6, function(k) {
    d <- panel |>
      group_by(biomarker) |>
      arrange(year, .by_group = TRUE) |>
      mutate(trials_lag = if (k == 0) trials else dplyr::lag(trials, k)) |>
      ungroup() |>
      filter(!is.na(trials_lag))
    fit <- glm(approvals ~ log1p(trials_lag) + year, family = quasipoisson(), data = d)
    b   <- coef(fit)[["log1p(trials_lag)"]]
    se  <- sqrt(vcov(fit)["log1p(trials_lag)", "log1p(trials_lag)"])
    tibble(lag_years = k, coef = b, lo = b - 1.96 * se, hi = b + 1.96 * se, n_obs = nrow(d))
  })

  list(
    modality_summary = modality_summary, modality_year = modality_year,
    modality_biomarker = modality_biomarker,
    region_year = region_year, region_profile_year = region_profile_year,
    region_biomarker = region_biomarker, china_only_biomarker = china_only_biomarker,
    portfolio_summary = portfolio_summary, portfolio_biomarker = portfolio_biomarker,
    portfolio_modality = portfolio_modality,
    first_approval = first_approval, approvals_panel = panel,
    event_study = event_study, event_biomarkers = event_biomarkers,
    lag_models = lag_models
  )
}

# ---- Plots --------------------------------------------------------------------------------
make_extension_plots <- function(ext, tabs) {
  plots <- list()
  skip_mod <- c("Other / unclassified", "Procedure / device", "Placebo / control")

  # 11. Modalities over time (share of biomarker-selected trials using each)
  top_mod <- ext$modality_summary |> filter(!modality %in% skip_mod) |>
    slice_max(n_bm, n = 9) |> pull(modality)
  d11 <- ext$modality_year |> filter(modality %in% top_mod) |>
    mutate(modality = factor(modality, levels = top_mod))
  plots$fig11_modality_trends <- ggplot(d11, aes(start_year, share_of_bm)) +
    geom_line(colour = PAL$industry, linewidth = 0.7) +
    geom_point(colour = PAL$industry, size = 1.1) +
    facet_wrap(~ modality, ncol = 3) +
    scale_y_continuous(labels = scales::label_percent(accuracy = 1), limits = c(0, NA)) +
    scale_x_continuous(breaks = scales::breaks_width(5)) +
    labs(title = "Which drug types biomarker-selected trials test",
         subtitle = "Share of each year's biomarker-selected trials that include the drug type (a trial can include several)",
         x = "Start year", y = "Share of biomarker-selected trials", caption = SOURCE_CAPTION) +
    theme_landscape(10)

  # 12. Modality x biomarker heatmap
  top_bm <- tabs$by_biomarker |> filter(in_headline) |> slice_max(n_trials, n = 15) |> pull(biomarker)
  d12 <- ext$modality_biomarker |>
    filter(modality %in% top_mod, biomarker %in% top_bm) |>
    complete(modality = top_mod, biomarker = top_bm, fill = list(n_trials = 0L)) |>
    mutate(modality = factor(modality, levels = rev(top_mod)),
           biomarker = factor(biomarker, levels = top_bm))
  plots$fig12_modality_biomarker <- ggplot(d12, aes(biomarker, modality, fill = n_trials)) +
    geom_tile(colour = "white", linewidth = 0.6) +
    geom_text(aes(label = ifelse(n_trials > 0, scales::comma(n_trials), "")),
              size = 2.7, colour = ifelse(d12$n_trials > stats::quantile(d12$n_trials, 0.8), "white", PAL$ink)) +
    scale_fill_gradientn(colours = PAL$seq, trans = "log1p", breaks = c(0, 10, 100, 1000),
                         name = "Trials") +
    labs(title = "Drug type by biomarker", subtitle = "Biomarker-selected trials testing each drug type",
         x = NULL, y = NULL, caption = SOURCE_CAPTION) +
    theme_landscape() +
    theme(axis.text.x = element_text(angle = 40, hjust = 1), panel.grid = element_blank(),
          legend.position = "right")

  # 13. Geography over time
  d13 <- ext$region_year |> mutate(region = factor(region, levels = REGION_LEVELS))
  plots$fig13_region_trends <- ggplot(d13, aes(start_year, share_of_bm_trials, colour = region)) +
    geom_line(linewidth = 0.8) +
    geom_point(size = 1.4) +
    scale_colour_manual(values = REGION_COLOURS, name = NULL) +
    scale_y_continuous(labels = scales::label_percent(accuracy = 1), limits = c(0, NA)) +
    scale_x_continuous(breaks = scales::breaks_width(2)) +
    labs(title = "Where biomarker-selected trials recruit",
         subtitle = "Share of each year's biomarker-selected trials with at least one site in the region (trials with sites listed)",
         x = "Start year", y = "Share of biomarker-selected trials", caption = SOURCE_CAPTION) +
    theme_landscape()

  # 14. Regional mix by biomarker, recent years
  keep14 <- ext$region_biomarker |> distinct(biomarker, n_with_sites) |>
    filter(n_with_sites >= 20) |> pull(biomarker)
  ord14 <- ext$region_biomarker |> filter(region == "China", biomarker %in% keep14) |>
    arrange(share) |> pull(biomarker)
  d14 <- ext$region_biomarker |>
    filter(biomarker %in% ord14, region %in% c("United States", "China", "Europe")) |>
    mutate(biomarker = factor(biomarker, levels = ord14),
           region = factor(region, levels = REGION_LEVELS))
  plots$fig14_region_biomarker <- ggplot(d14, aes(share, biomarker, colour = region)) +
    geom_line(aes(group = biomarker), colour = PAL$grid, linewidth = 1.2) +
    geom_point(size = 2.8) +
    scale_colour_manual(values = REGION_COLOURS, name = NULL) +
    scale_x_continuous(labels = scales::label_percent(accuracy = 1), limits = c(0, 1)) +
    labs(title = sprintf("Regional footprint by biomarker, trials started %d–%d",
                         CFG$recent_years[1], CFG$recent_years[2]),
         subtitle = "Share of trials with at least one site in the region; sorted by China share",
         x = "Share of trials", y = NULL, caption = SOURCE_CAPTION) +
    theme_landscape()

  # 15. Company portfolios: sponsor x biomarker
  top_sp <- ext$portfolio_summary |> slice_max(n_bm_trials, n = 15, with_ties = FALSE) |> pull(parent)
  d15 <- ext$portfolio_biomarker |>
    filter(parent %in% top_sp, biomarker %in% top_bm) |>
    complete(parent = top_sp, biomarker = top_bm,
             fill = list(n_trials = 0L, share_of_portfolio = 0)) |>
    mutate(parent = factor(parent, levels = rev(top_sp)),
           biomarker = factor(biomarker, levels = top_bm))
  plots$fig15_portfolio_biomarker <- ggplot(d15, aes(biomarker, parent, fill = share_of_portfolio)) +
    geom_tile(colour = "white", linewidth = 0.6) +
    geom_text(aes(label = ifelse(n_trials > 0, n_trials, "")), size = 2.6,
              colour = ifelse(d15$share_of_portfolio > 0.25, "white", PAL$ink)) +
    scale_fill_gradientn(colours = c("#f4f4f2", PAL$seq), labels = scales::label_percent(),
                         name = "Share of\nsponsor's\nbiomarker\ntrials") +
    labs(title = "Company portfolios: which biomarkers each sponsor bets on",
         subtitle = "Colour = share of the sponsor's biomarker-selected trials; number = trials. Subsidiaries mapped to current parent.",
         x = NULL, y = NULL, caption = SOURCE_CAPTION) +
    theme_landscape() +
    theme(axis.text.x = element_text(angle = 40, hjust = 1), panel.grid = element_blank(),
          legend.position = "right")

  # 16. Company portfolios: sponsor x modality
  d16 <- ext$portfolio_modality |>
    filter(parent %in% top_sp, modality %in% top_mod) |>
    complete(parent = top_sp, modality = top_mod,
             fill = list(n_trials = 0L, share_of_portfolio = 0)) |>
    mutate(parent = factor(parent, levels = rev(top_sp)),
           modality = factor(modality, levels = top_mod))
  plots$fig16_portfolio_modality <- ggplot(d16, aes(modality, parent, fill = share_of_portfolio)) +
    geom_tile(colour = "white", linewidth = 0.6) +
    geom_text(aes(label = ifelse(n_trials > 0, n_trials, "")), size = 2.6,
              colour = ifelse(d16$share_of_portfolio > 0.3, "white", PAL$ink)) +
    scale_fill_gradientn(colours = c("#f4f4f2", PAL$seq), labels = scales::label_percent(),
                         name = "Share of\nsponsor's\ntrials") +
    labs(title = "Company portfolios: drug types in each sponsor's biomarker-selected trials",
         x = NULL, y = NULL, caption = SOURCE_CAPTION) +
    theme_landscape() +
    theme(axis.text.x = element_text(angle = 40, hjust = 1), panel.grid = element_blank(),
          legend.position = "right")

  # 17. Trial starts vs FDA approvals per biomarker
  bm17 <- intersect(top_bm, unique(ext$first_approval$biomarker))[1:12]
  bm17 <- bm17[!is.na(bm17)]
  d17  <- ext$approvals_panel |> filter(biomarker %in% bm17) |>
    mutate(biomarker = factor(biomarker, levels = bm17))
  plots$fig17_trials_vs_approvals <- ggplot(d17, aes(year, trials)) +
    geom_vline(data = filter(d17, approvals > 0), aes(xintercept = year),
               colour = PAL$non_industry, linewidth = 0.5, linetype = "dashed") +
    geom_line(colour = PAL$industry, linewidth = 0.7) +
    facet_wrap(~ biomarker, scales = "free_y", ncol = 4) +
    scale_x_continuous(breaks = scales::breaks_width(5)) +
    scale_y_continuous(limits = c(0, NA)) +
    labs(title = "Trial starts and FDA approvals by biomarker",
         subtitle = "Blue: biomarker-selected trial starts per year. Dashed orange: years with a biomarker-defined FDA approval",
         x = "Year", y = "Trials", caption = paste(SOURCE_CAPTION, "Approvals: reference/fda_biomarker_approvals.csv.")) +
    theme_landscape(10)

  # 18. Event study around first approval
  plots$fig18_event_study <- ggplot(ext$event_study, aes(rel_year, mean_index)) +
    geom_vline(xintercept = 0, colour = PAL$non_industry, linetype = "dashed") +
    geom_hline(yintercept = 1, colour = PAL$ink2, linewidth = 0.3) +
    geom_ribbon(aes(ymin = mean_index - 1.96 * se, ymax = mean_index + 1.96 * se),
                fill = PAL$seq[2], alpha = 0.6) +
    geom_line(colour = PAL$industry, linewidth = 0.9) +
    geom_point(colour = PAL$industry, size = 2) +
    scale_x_continuous(breaks = -5:4) +
    labs(title = "Trial activity around a biomarker's first FDA approval",
         subtitle = sprintf("Biomarker's share of all biomarker-selected trial starts, indexed to its own average (1 = average)\n%d biomarkers; band = 95%% CI",
                            nrow(ext$event_biomarkers)),
         x = "Years relative to first approval", y = "Share of trial starts (index)",
         caption = SOURCE_CAPTION) +
    theme_landscape()

  # 19. Lead-lag model
  plots$fig19_lag_models <- ggplot(ext$lag_models, aes(lag_years, coef)) +
    geom_hline(yintercept = 0, colour = PAL$ink2, linewidth = 0.3) +
    geom_pointrange(aes(ymin = lo, ymax = hi), colour = PAL$industry) +
    scale_x_continuous(breaks = 0:6) +
    labs(title = "Do trial starts predict approvals k years later?",
         subtitle = "Effect of log(1 + trial starts k years earlier) on approvals per biomarker-year\nquasi-Poisson model with linear time trend",
         x = "Lag k (years)", y = "Coefficient (95% CI)", caption = SOURCE_CAPTION) +
    theme_landscape()

  sizes <- list(fig11_modality_trends = c(10, 7.5), fig12_modality_biomarker = c(11, 6.5),
                fig13_region_trends = c(9.5, 5.5), fig14_region_biomarker = c(9, 7.5),
                fig15_portfolio_biomarker = c(11.5, 7.5), fig16_portfolio_modality = c(10, 7.5),
                fig17_trials_vs_approvals = c(11, 7.5), fig18_event_study = c(8.5, 5),
                fig19_lag_models = c(8.5, 5))
  for (nm in names(plots)) {
    s <- sizes[[nm]] %||% c(9, 5.5)
    save_fig(plots[[nm]], nm, width = s[1], height = s[2])
  }
  invisible(plots)
}

write_extension_tables <- function(ext) {
  for (nm in names(ext)) {
    readr::write_csv(ext[[nm]], file.path(CFG$out_dir, paste0("ext_", nm, ".csv")))
  }
  message("  extension tables written to ", CFG$out_dir)
}
