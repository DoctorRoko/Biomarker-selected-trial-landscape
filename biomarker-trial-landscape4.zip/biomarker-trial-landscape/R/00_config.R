# =============================================================================
# 00_config.R — packages, parameters, shared helpers
# =============================================================================

pkgs <- c("httr2", "jsonlite", "dplyr", "tidyr", "stringr", "purrr", "tibble",
          "readr", "ggplot2", "forcats", "scales", "ggrepel", "patchwork")
missing_pkgs <- pkgs[!vapply(pkgs, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_pkgs)) install.packages(missing_pkgs)
suppressPackageStartupMessages(invisible(lapply(pkgs, library, character.only = TRUE)))

`%||%` <- function(x, y) if (is.null(x)) y else x

# ---- Parameters -------------------------------------------------------------
CFG <- list(
  # Trial start-date window. 2026 is excluded because it is incomplete.
  start_from = "2005-01-01",
  start_to   = "2025-12-31",

  # TRUE = download only 3 pages (~3,000 trials) for a fast dry run.
  test_mode  = FALSE,
  page_size  = 1000,
  refresh    = FALSE,            # TRUE = ignore the cached download

  # Keep only trials whose primary purpose is TREATMENT (drops screening,
  # supportive care, prevention...). Trials with no purpose recorded are kept.
  treatment_only = TRUE,

  # Biomarker groups that are recorded but do NOT make a trial count as
  # "biomarker-selected" in the headline numbers (lineage antigens such as
  # CD19/CD20 describe the disease rather than select a molecular subgroup).
  primary_exclude_groups = c("Haematologic lineage antigen"),

  # Growth model window and minimum size for an area to get a growth estimate
  growth_years     = c(2012, 2025),
  recent_years     = c(2021, 2025),
  min_trials_growth = 30,

  # Tumour classification: "mesh_first" (MeSH terms, free text when no MeSH
  # match), "text" (free text only, as in the first version) or "union".
  tumour_method = "mesh_first",

  # Drug type: classify interventions in EXPERIMENTAL arms ("experimental"),
  # falling back to all interventions when arms are not recorded; or "all".
  modality_arms = "experimental",

  # Optional modules (they need extra input, so they are off by default)
  run_llm_crosscheck = FALSE,   # needs ANTHROPIC_API_KEY; see R/10_llm_crosscheck.R
  llm_model          = "claude-haiku-5-5",
  llm_sample_size    = 300,
  ictrp_file         = file.path("data", "ictrp_export.csv"),  # see R/11_other_registries.R

  # Outcome analysis only uses trials started up to this year, so recent
  # trials have had time to finish or stop.
  outcome_max_start_year = 2020,

  data_dir = "data",
  out_dir  = "output",
  fig_dir  = file.path("output", "figures"),
  seed     = 2026
)

for (d in c(CFG$data_dir, CFG$out_dir, CFG$fig_dir)) {
  dir.create(d, showWarnings = FALSE, recursive = TRUE)
}

# ---- Plot style (validated categorical palette, single-hue sequential) ------
PAL <- list(
  industry     = "#2a78d6",   # categorical slot 1 (blue)
  non_industry = "#eb6834",   # categorical slot 2 (orange)
  accent       = "#1baf7a",   # slot 3
  ink          = "#0b0b0b",
  ink2         = "#52514e",
  grid         = "#e4e3df",
  seq          = c("#cde2fb", "#9ec5f4", "#6da7ec", "#3987e5",
                   "#256abf", "#184f95", "#0d366b")
)

theme_landscape <- function(base_size = 11) {
  theme_minimal(base_size = base_size) +
    theme(
      text             = element_text(colour = PAL$ink),
      axis.text        = element_text(colour = PAL$ink2),
      plot.title       = element_text(face = "bold", size = base_size + 2),
      plot.subtitle    = element_text(colour = PAL$ink2),
      plot.caption     = element_text(colour = PAL$ink2, size = base_size - 2, hjust = 0),
      panel.grid.minor = element_blank(),
      panel.grid.major = element_line(colour = PAL$grid, linewidth = 0.3),
      legend.position  = "top",
      legend.justification = "left",
      strip.text       = element_text(face = "bold", hjust = 0),
      plot.background  = element_rect(fill = "white", colour = NA)
    )
}

# ---- Figure plan ------------------------------------------------------------
# The pipeline computes many plots; only a curated set is saved.
#   main          -> output/figures/main/          (in the report and manuscript)
#   supplementary -> output/figures/supplementary/ (appendix of the report)
#   anything not listed is not saved (its content lives in a composite figure)
FIGURE_PLAN <- tibble::tribble(
  ~internal,                    ~set,            ~file,
  "fig_main1_landscape",        "main",          "Figure1_landscape",
  "fig_main2_investment",       "main",          "Figure2_investment_geography_approvals",
  "fig21_termination_forest",   "main",          "Figure3_trial_outcomes",
  "fig20_sensitivity",          "main",          "Figure4_sensitivity",
  "fig3_tumour_types",          "supplementary", "S1_tumour_types",
  "fig5_biomarker_trends",      "supplementary", "S2_biomarker_trends",
  "fig6_tumour_share_trends",   "supplementary", "S3_tumour_share_trends",
  "fig8_investment_biomarker",  "supplementary", "S4_investment_map_biomarkers",
  "fig12_modality_biomarker",   "supplementary", "S5_drug_type_by_biomarker",
  "fig14_region_biomarker",     "supplementary", "S6_regions_by_biomarker",
  "fig17_trials_vs_approvals",  "supplementary", "S7_trials_vs_approvals",
  "fig22_stop_reasons",         "supplementary", "S8_stop_reasons",
  "fig25_designs",              "supplementary", "S9_trial_designs",
  "fig26_liquid_biopsy",        "supplementary", "S10_liquid_biopsy",
  "fig27_registries_china",     "supplementary", "S11_registries_china"
)

fig_path <- function(internal) {
  row <- FIGURE_PLAN[FIGURE_PLAN$internal == internal, ]
  if (nrow(row) == 0) return(NA_character_)
  file.path(CFG$fig_dir, row$set, paste0(row$file, ".png"))
}

# Remove figures from earlier runs (including old file names) before plotting
clear_figures <- function() {
  old <- list.files(CFG$fig_dir, pattern = "\\.png$", full.names = TRUE, recursive = TRUE)
  unlink(old)
  for (d in c("main", "supplementary")) dir.create(file.path(CFG$fig_dir, d), showWarnings = FALSE, recursive = TRUE)
}

save_fig <- function(plot, name, width = 9, height = 6) {
  path <- fig_path(name)
  if (is.na(path)) return(invisible(NULL))          # not in the curated set
  dir.create(dirname(path), showWarnings = FALSE, recursive = TRUE)
  ggsave(path, plot, width = width, height = height, dpi = 220, bg = "white")
  message("  saved ", path)
  invisible(path)
}

SOURCE_CAPTION <- "Source: ClinicalTrials.gov API v2; interventional oncology treatment trials. Biomarker selection detected by text-mining inclusion criteria and titles."
