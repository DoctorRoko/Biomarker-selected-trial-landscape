# Run the unit tests for the classification rules (no download needed)
if (!requireNamespace("testthat", quietly = TRUE)) install.packages("testthat")
testthat::test_dir("tests/testthat", reporter = "summary", stop_on_failure = TRUE)
